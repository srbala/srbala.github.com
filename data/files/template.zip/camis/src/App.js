import React, { Component } from 'react';
import {Button} from 'primereact/components/button/Button';
import logo from './logo.svg';
import './App.css';
import 'babel-polyfill';
import 'primereact/resources/themes/omega/theme.css';
import 'primereact/resources/primereact.min.css';
import 'font-awesome/css/font-awesome.css';

class App extends Component {

  constructor() {
    super();
    this.state = {count: 0};
    this.increment = this.increment.bind(this);
  }

  increment() {
      this.setState({count: this.state.count + 1});
  }
  
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <p className="App-intro">
          <Button label="Click" onClick={this.increment} />
          <p>Number of Clicks: {this.state.count}</p>
        </p>
      </div>
    );
  }
}

export default App;
