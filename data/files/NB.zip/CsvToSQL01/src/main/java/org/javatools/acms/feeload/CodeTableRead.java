/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template_split file, choose Tools | Templates
 * and open the template_split in the editor.
 */
package org.javatools.acms.feeload;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.javatools.io.IOUtils;

/**
 *
 * @author srbala
 */
public class CodeTableRead {

    private static final String template_split = "INSERT INTO CVT_FEESPLITS VALUES ('${DOCKTYPE}', '${DOCTYPE}', '20141101', '20991231',\r\n${NEW_FEE}, ${2014_Inr.}, ${2002_Incr.}, ${1996_Incr.}, ${Unallocated}, 'CVFEELOD', current_date, 'CVFEELOD',\r\ncurrent_date, 'A');\r\n";
    private static final String template_stdfee = "INSERT INTO CVT_STDFEES " + 
            "(DOCKET_TYPE_CD, DOCUMENT_TYPE_CODE," +
   "\r\nFEE_EFFECTIVE_DT, FEE_AMOUNT, FEE_TOLER_PLUS_AMT, FEE_TOLER_MIN_AMT," +
   "\r\nASSET_ACCOUNT_CODE, DISTRIBUTED_CODE_1, DISTRIBUTED_CODE_2," +
   "\r\nDISTRIBUTED_CODE_3, DISTRIBUTED_CODE_4, DISTRIBUTED_CODE_5," +
   "\r\nDISTRIBUTED_CODE_6, DISTRIBUTED_AMT_1, DISTRIBUTED_AMT_2," +
   "\r\nDISTRIBUTED_AMT_3, DISTRIBUTED_AMT_4, DISTRIBUTED_AMT_5," +
   "\r\nDISTRIBUTED_AMT_6, ADDITION_PTYS_AMT, ENTRIES_COUNT, LAST_MAINT_DT," +
   "\r\nRECORD_STATUS_CD, OPERATOR_ID, ENTERED_DT, VAR_CNTY_FEE_IND) VALUES" + 
   "\r\n('${DOCKTYPE}', '${DOCTYPE}', '20141101', ${NEW_FEE}, 0, 0, '${ASSET}', '${DISTRIB1}', '', '', '',\r\n'', '', ${NEW_FEE}, 0, 0, 0, 0, 0, 0, 1, '00000000', 'A', 'CVFEELOD', \r\n'20141101', '${Variable_Fee}');\r\n";

    public static void main(String[] args) {
        FileOutputStream fos1 = null;
        FileOutputStream fos2 = null;
        Map<String, String> lineData = null;
        try {
            fos1 = new FileOutputStream(new File("C:/NB/Acms/splfeedj.sql"));
            fos2 = new FileOutputStream(new File("C:/NB/Acms/stdfeedj1.sql"));
            BufferedWriter bw1 = new BufferedWriter(new OutputStreamWriter(fos1));
            BufferedWriter bw2 = new BufferedWriter(new OutputStreamWriter(fos2));
            //bw1.write("SET SCHEMA DBAD;\r\n");
            //bw2.write("SET SCHEMA DBAD;\r\n");
            List<String> lines;
            InputStream data1 = null;
            try {
                //data = new FileInputStream("C:/NB/Acms/FinalFee.csv");
                data1 = new FileInputStream("C:/Tmp/docresult.csv");
            } catch (FileNotFoundException ex) {
                Logger.getLogger(CodeTableRead.class.getName()).log(Level.SEVERE, null, ex);
            }
            lines = null;
            if (data1 != null) {
                try {
                    lines = IOUtils.readLines(data1);
                    data1.close();
                } catch (IOException ex) {
                    Logger.getLogger(CodeTableRead.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            String[] fields;
            int row = 0;
            int recs = 0;
            int len;
             
            if (lines != null && !lines.isEmpty()) {
                lines.remove(0);
                System.out.println("Total records found is " + lines.size());
                lineData = new HashMap<>(lines.size());
                for (String line : lines) {
                    fields = line.split("\",\"");
                    len = fields.length;
                    if (len >= 2) {
                        if (fields[1] != null && fields[1].trim().length() > 0) {
                            row++;
                            recs++;
                            try {
                                lineData.put(fields[0].replaceAll("\"", ""), fields[1].replaceAll("\"", ""));
                            } catch (IndexOutOfBoundsException e) {
                                System.out.println("ERROR:" + row + ": N" );
                            }
                        } else {
                            System.out.println("row" + row + ", : " + fields[1]);
                        }
                    }
                }

            }
            System.out.println("Total doctype processed is " + recs);
            recs = 0;
            try {
                //data = new FileInputStream("C:/NB/Acms/FinalFee.csv");
                data1 = new FileInputStream("C:/NB/Acms/djdoc.csv");
            } catch (FileNotFoundException ex) {
                Logger.getLogger(CodeTableRead.class.getName()).log(Level.SEVERE, null, ex);
            }
            lines = null;
            if (data1 != null) {
                try {
                    lines = IOUtils.readLines(data1);
                    data1.close();
                } catch (IOException ex) {
                    Logger.getLogger(CodeTableRead.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            String value;
            if (lines != null) {
                lines.remove(0);
                if (!lines.isEmpty()) {
                    System.out.println("Total records found is " + lines.size());
                    for (String line : lines) {
                        fields = line.split(",");
                        if (fields.length >= 2 && fields[1] != null) {
                            if (lineData != null)
                                value = lineData.get(fields[1].trim().toUpperCase());
                            else 
                                value = null;
                            if (value == null) {
                                value = fields[1];
                            }
                            bw1.write(value + "\r\n");
                        }
                    }
                }
            }
            bw2.flush();
            bw1.flush();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(CodeTableRead.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(CodeTableRead.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (fos1 != null) {
                    fos1.close();
                }
                if (fos2 != null) {
                    fos2.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(CodeTableRead.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        System.out.println(lineData.get("XK1"));
        System.out.println(lineData.get("MT4"));
    }

    public static String generateLineContent(Map<String, String> dataMap, String lineTemplate) {

        Pattern pattern = Pattern.compile("\\$\\{(.+?)\\}");
        Matcher matcher = pattern.matcher(lineTemplate);

        Map<String, String> replacements = dataMap;
        StringBuilder lineContent = new StringBuilder();
        int i = 0;

        while (matcher.find()) {
            String replacement = replacements.get(matcher.group(1));
            lineContent.append(lineTemplate.substring(i, matcher.start()));
            if (replacement == null) {
                lineContent.append("");
            } else {
                lineContent.append(replacement);
            }
            i = matcher.end();
        }
        lineContent.append(lineTemplate.substring(i, lineTemplate.length()));
        return lineContent.toString();
    }

}
