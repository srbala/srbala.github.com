/*  
 * To change this license header, choose License Headers in Project Properties.
 * To change this template_split file, choose Tools | Templates
 * and open the template_split in the editor.
 */
package org.javatools.acms.feeload;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.javatools.io.IOUtils;

/**
 *
 * @author srbala
 */
public class CodeTableUsingSubstring {

    private static final String template_split = "INSERT INTO CVT_TABL "
        + "(CVTABL_TABLE_NAME, CVTABL_SEQNO, CVTABL_VALUE1,\r\n "
        + "CVTABL_VALUE2, CVTABL_INDICATOR) VALUES ('${CVTABL_TABLE_NAME}', "
        + "'${CVTABL_SEQNO}',\r\n'${CVTABL_VALUE1}', '${CVTABL_VALUE2}'\r\n, "
        + "'${CVTABL_INDICATOR}');\r\n";

//    private static final String template_stdfee = 

    public static void main(String[] args) {
        FileOutputStream fos1 = null;
        //FileOutputStream fos2 = null;
        try {
            fos1 = new FileOutputStream(new File("/Tmp/ord.sql"));
            BufferedWriter bw1 = new BufferedWriter(new OutputStreamWriter(fos1));
            bw1.write("SET SCHEMA DBAD;\r\n");
            List<String> lines;
            InputStream data = null;
            try {
                data = new FileInputStream("/Tmp/ord.csv");
            } catch (FileNotFoundException ex) {
                Logger.getLogger(FeeSQLGenFromCsv.class.getName()).log(Level.SEVERE, null, ex);
            }
            lines = null;
            if (data != null) {
                try {
                    lines = IOUtils.readLines(data);
                    data.close();
                } catch (IOException ex) {
                    Logger.getLogger(FeeSQLGenFromCsv.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            String[] fields;
            int row = 0;
            int recs = 0;
            int len;
            int idx = 0;
            Map<String, String> lineData = new HashMap<>();
            if (lines != null && !lines.isEmpty()) {
                String headerLine = lines.remove(0).trim(); //remove header line

                String[] header = headerLine.replaceAll(" ", "_").split(",");
                System.out.println("Total records found is " + lines.size());
                len = 5;
                //fields = new String[len];
                for (String line : lines) {
                    line = line.trim();
                    //fields = line.split(",");
                    //len = fields.length;
                    //if(lineData == null) lineData = new HashMap<>();
                    lineData.clear();
                    if (line.length() > 0) {
                        fields = new String[len];
                        fields[0] = line.substring(0, 8);
                        fields[1] = line.substring(18, 19);
                        fields[2] = line.substring(35, 39);
                        fields[3] = line.substring(48, 59).trim();
                        fields[4] = line.substring(83);
                        if (fields[0] != null && fields[0].trim().length() > 0) {
                            row++;
                            recs++;
                            //System.out.println("row" + row + ", " + header[1] + ": " + fields[1]);
                            try {
                                for (idx = 0; idx <= 4; idx++) {
                                    lineData.put(header[idx], fields[idx]);
//                                    if (idx == 0 || idx == 1) {
//                                        lineData.put(header[idx], fields[idx].toUpperCase());
//                                    } else {
//                                        lineData.put(header[idx], fields[idx]);
//                                    }
                                    //System.out.println("row" + row + ", " + header[idx] + ": " + fields[idx]);
                                }
                            } catch (IndexOutOfBoundsException e) {
                                //System.out.println("row" + row+ ", " + header[idx] + ": N" );
                                lineData.put(header[idx], " ");
                            }
                            if (fields[0].startsWith("CV"))
                                bw1.write(generateLineContent(lineData, template_split));
                        } else {
                            System.out.println("row" + row + ", " + header[1] + ": " + fields[1]);
                        }
                    }
                    if (row >= 250) {
                        bw1.write("COMMIT;\r\n");
                        row = 0;
                    }
                }

            }
            bw1.write("COMMIT;\r\n");
            System.out.println("Total records processed is " + recs);
            bw1.flush();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FeeSQLGenFromCsv.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FeeSQLGenFromCsv.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (fos1 != null) {
                    fos1.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(FeeSQLGenFromCsv.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static String generateLineContent(Map<String, String> dataMap, String lineTemplate) {

        Pattern pattern = Pattern.compile("\\$\\{(.+?)\\}");
        Matcher matcher = pattern.matcher(lineTemplate);

        Map<String, String> replacements = dataMap;
        StringBuilder lineContent = new StringBuilder();
        int i = 0;

        while (matcher.find()) {
            String replacement = replacements.get(matcher.group(1));
            lineContent.append(lineTemplate.substring(i, matcher.start()));
            if (replacement == null) {
                lineContent.append("");
            } else {
                lineContent.append(replacement);
            }
            i = matcher.end();
        }
        lineContent.append(lineTemplate.substring(i, lineTemplate.length()));
        return lineContent.toString();
    }

}

