/*  
 * To change this license header, choose License Headers in Project Properties.
 * To change this template_split file, choose Tools | Templates
 * and open the template_split in the editor.
 */
package org.javatools.acms.feeload;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static org.javatools.acms.feeload.AtcStatSql.generateLineContent;
import org.javatools.io.IOUtils;

/**
 *
 * @author srbala
 */
public class SWPostFirmErrorParser {
private static final String template_split1 = 
            "update cvt_attyfrm set ELCTR_FILER_IND = 'N'\r\n" +
            "where atty_firm_id = '${ACMSFIRM}' and ELCTR_FILER_IND = 'E';\r\n";
          //  + "AND ATTY_FIRM_ID = '${ACMSFIRM}' AND ATTYFRM_ID_KEY = ${FRMKEY};\r\n";

    public static void main(String[] args) {
        FileOutputStream fos1 = null;
        FileOutputStream fos2 = null;
        
        try {
            fos1 = new FileOutputStream(new File("/Tmp/swpostattyerr.txt"));
            BufferedWriter bw1 = new BufferedWriter(new OutputStreamWriter(fos1));
            fos2 = new FileOutputStream(new File("/Tmp/swpostattyerr.sql"));
            BufferedWriter bw2 = new BufferedWriter(new OutputStreamWriter(fos2));
            bw2.write("SET SCHEMA DBAP;\r\n");
            List<String> lines;
            InputStream data = null;
            try {
                data = new FileInputStream("/Tmp/SWPost.log");
            } catch (FileNotFoundException ex) {
                Logger.getLogger(FeeSQLGenFromCsv.class.getName()).log(Level.SEVERE, null, ex);
            }
            lines = null;
            if (data != null) {
                try {
                    lines = IOUtils.readLines(data);
                    data.close();
                } catch (IOException ex) {
                    Logger.getLogger(FeeSQLGenFromCsv.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            String[] fields;
            int row = 0;
            int recs = 0;
            int len;
            int idx = 0;
            Map<String, String> lineData = new HashMap<>();
            if (lines != null && !lines.isEmpty()) {
                String headerLine = lines.remove(0).trim(); //remove header line

                //fields = new String[len];
                for (String line : lines) {
                    if (line.contains("Firm info not found for Firm ID")) {
                        bw1.write(line.substring(43).trim()  +"\r\n");
                        lineData.clear();
                        lineData.put("ACMSFIRM", line.substring(43).trim());
                        bw2.write(generateLineContent(lineData, template_split1));
                        ++recs;
                    }
                }

            }
            bw2.write("COMMIT;\r\n");
            System.out.println("Total records processed is " + recs);
            bw1.flush();
            bw2.flush();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FeeSQLGenFromCsv.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FeeSQLGenFromCsv.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (fos1 != null) {
                    fos1.close();
                }
                if (fos2 != null) {
                    fos2.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(FeeSQLGenFromCsv.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static String generateLineContent(Map<String, String> dataMap, String lineTemplate) {

        Pattern pattern = Pattern.compile("\\$\\{(.+?)\\}");
        Matcher matcher = pattern.matcher(lineTemplate);

        Map<String, String> replacements = dataMap;
        StringBuilder lineContent = new StringBuilder();
        int i = 0;

        while (matcher.find()) {
            String replacement = replacements.get(matcher.group(1));
            lineContent.append(lineTemplate.substring(i, matcher.start()));
            if (replacement == null) {
                lineContent.append("");
            } else {
                lineContent.append(replacement);
            }
            i = matcher.end();
        }
        lineContent.append(lineTemplate.substring(i, lineTemplate.length()));
        return lineContent.toString();
    }

}

