/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template_split file, choose Tools | Templates
 * and open the template_split in the editor.
 */
package org.javatools.acms.feeload;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.javatools.io.IOUtils;

/**
 *
 * @author srbala
 */
public class CodeTableSQL {

    private static final String template_split = "INSERT INTO CVT_TABL VALUES ('${col1}', '${col2}', '${col3}', '${col4}', '${col5}');\r\n";

    public static void main(String[] args) {
        FileOutputStream fos1 = null;
        FileOutputStream fos2 = null;
        Map<String, String> lineData = null;
        try {
            fos1 = new FileOutputStream(new File("C:/NB/Acms/codeloada.sql"));
            BufferedWriter bw1 = new BufferedWriter(new OutputStreamWriter(fos1));
            //bw1.write("SET SCHEMA DBAD;\r\n");
            List<String> lines;
            InputStream data1 = null;
            try {
                //data = new FileInputStream("C:/NB/Acms/FinalFee.csv");
                data1 = new FileInputStream("C:/temp/CVTDC145.TXT");
            } catch (FileNotFoundException ex) {
                Logger.getLogger(CodeTableSQL.class.getName()).log(Level.SEVERE, null, ex);
            }
            lines = null;
            if (data1 != null) {
                try {
                    lines = IOUtils.readLines(data1);
                    data1.close();
                } catch (IOException ex) {
                    Logger.getLogger(CodeTableSQL.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            String[] fields;
            int row = 0;
            int recs = 0;
            int len;
             
            if (lines != null && !lines.isEmpty()) {
                //lines.remove(0);
                System.out.println("Total records found is " + lines.size());
                lineData = new HashMap<>(lines.size());
                for (String line : lines) {
                    fields = line.split("\",\"");
                    len = fields.length;
                    if (len >= 2) {
                        if (fields[1] != null && fields[1].trim().length() > 0) {
                            row++;
                            recs++;
                            try {
                                lineData.put(fields[0].replaceAll("\"", ""), fields[1].replaceAll("\"", ""));
                            } catch (IndexOutOfBoundsException e) {
                                System.out.println("ERROR:" + row + ": N" );
                            }
                        } else {
                            System.out.println("row" + row + ", : " + fields[1]);
                        }
                    }
                }

            }
            System.out.println("Total processed is " + recs);
            recs = 0;
            try {
                //data = new FileInputStream("C:/NB/Acms/FinalFee.csv");
                data1 = new FileInputStream("C:/NB/Acms/djdoc.csv");
            } catch (FileNotFoundException ex) {
                Logger.getLogger(CodeTableSQL.class.getName()).log(Level.SEVERE, null, ex);
            }
            lines = null;
            if (data1 != null) {
                try {
                    lines = IOUtils.readLines(data1);
                    data1.close();
                } catch (IOException ex) {
                    Logger.getLogger(CodeTableSQL.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            String value;
            if (lines != null) {
                lines.remove(0);
                if (!lines.isEmpty()) {
                    System.out.println("Total records found is " + lines.size());
                    for (String line : lines) {
                        fields = line.split(",");
                        if (fields.length >= 2 && fields[1] != null) {
                            if (lineData != null)
                                value = lineData.get(fields[1].trim().toUpperCase());
                            else 
                                value = null;
                            if (value == null) {
                                value = fields[1];
                            }
                            bw1.write(value + "\r\n");
                        }
                    }
                }
            }
            bw1.flush();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(CodeTableSQL.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(CodeTableSQL.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (fos1 != null) {
                    fos1.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(CodeTableSQL.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static String generateLineContent1(Map<String, String> dataMap, String lineTemplate) {

        Pattern pattern = Pattern.compile("\\$\\{(.+?)\\}");
        Matcher matcher = pattern.matcher(lineTemplate);

        Map<String, String> replacements = dataMap;
        StringBuilder lineContent = new StringBuilder();
        int i = 0;

        while (matcher.find()) {
            String replacement = replacements.get(matcher.group(1));
            lineContent.append(lineTemplate.substring(i, matcher.start()));
            if (replacement == null) {
                lineContent.append("");
            } else {
                lineContent.append(replacement);
            }
            i = matcher.end();
        }
        lineContent.append(lineTemplate.substring(i, lineTemplate.length()));
        return lineContent.toString();
    }

}
