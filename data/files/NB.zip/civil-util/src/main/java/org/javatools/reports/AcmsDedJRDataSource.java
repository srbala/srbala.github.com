/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.javatools.reports;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.javatools.io.IOUtils;

/**
 *
 * @author srbala
 */
public class AcmsDedJRDataSource {
    public Collection getAcmsDedData() {
        try {
            InputStream in = AcmsDedJRDataSource.class.getResourceAsStream( "DISCOV.TXT" );
            List<String> lines = IOUtils.readLines(in);
            if (lines != null) {
                List<AcmsDed> data;
                data = new ArrayList<AcmsDed>();
                int index = 0;
                for (String line: lines) {
                    if (line != null && index > 0) {
                        data.add(formatAcmsDed(line, index++));
                    } else {
                        index++;
                    }
                }
                return data;
            }
        } catch (IOException ex) {
            Logger.getLogger(AcmsDedJRDataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new ArrayList<AcmsDed>(1);
    }

    private AcmsDed formatAcmsDed(String line, int index) {
        String[] fields = line.split(";");
        AcmsDed ded = new AcmsDed();
        ded.setSeqNo(Integer.toString(index));
        ded.setVenueAddressLine1(fields[0]);
        ded.setVenueAddressLine2(fields[1]);
        ded.setVenueAddressLine3(fields[2]);
        ded.setVenueAddressLine4(fields[3]);
        ded.setVenuePhone(fields[4]);
        ded.setTodayDate(fields[5]);
        ded.setCaseTitle(fields[6]);
        ded.setCaseKey(fields[7]);
        ded.setBodyLine1(fields[8]);
        ded.setBodyLine25(fields[9]);
        ded.setBodyLine69(fields[10]);
        ded.setMailLine1(fields[11]);
        ded.setMailLine2(fields[12]);
        ded.setMailLine3(fields[13]);
        try {
            ded.setMailLine4(fields[14]);
        } catch (Exception e) {
            ded.setMailLine4("");
        }
        try {
            ded.setMailLine5(fields[15]);
        } catch (Exception e) {
            ded.setMailLine5("");
        }
        return ded;
    }
}
