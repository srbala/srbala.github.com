/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.javatools.reports;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.javatools.io.IOUtils;

/**
 *
 * @author srbala
 */
public class AcmsDed {
    private String seqNo;
    private String venueAddressLine1;
    private String venueAddressLine2;
    private String venueAddressLine3;
    private String venueAddressLine4;
    private String venuePhone;
    private String todayDate;
    private String discoveryEndDate;
    private String mailLine1;
    private String mailLine2;
    private String mailLine3;
    private String mailLine4;
    private String mailLine5;
    private String bodyLine1;
    private String bodyLine25;
    private String bodyLine69;
    private String caseTitle;
    private String caseKey;

    /**
     * @return the seqNo
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * @param seqNo the seqNo to set
     */
    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * @return the venueAddressLine1
     */
    public String getVenueAddressLine1() {
        return venueAddressLine1;
    }

    /**
     * @param venueAddressLine1 the venueAddressLine1 to set
     */
    public void setVenueAddressLine1(String venueAddressLine1) {
        this.venueAddressLine1 = venueAddressLine1;
    }

    /**
     * @return the venueAddressLine2
     */
    public String getVenueAddressLine2() {
        return venueAddressLine2;
    }

    /**
     * @param venueAddressLine2 the venueAddressLine2 to set
     */
    public void setVenueAddressLine2(String venueAddressLine2) {
        this.venueAddressLine2 = venueAddressLine2;
    }

    /**
     * @return the venueAddressLine3
     */
    public String getVenueAddressLine3() {
        return venueAddressLine3;
    }

    /**
     * @param venueAddressLine3 the venueAddressLine3 to set
     */
    public void setVenueAddressLine3(String venueAddressLine3) {
        this.venueAddressLine3 = venueAddressLine3;
    }

    /**
     * @return the venueAddressLine4
     */
    public String getVenueAddressLine4() {
        return venueAddressLine4;
    }

    /**
     * @param venueAddressLine4 the venueAddressLine4 to set
     */
    public void setVenueAddressLine4(String venueAddressLine4) {
        this.venueAddressLine4 = venueAddressLine4;
    }

    /**
     * @return the venuePhone
     */
    public String getVenuePhone() {
        return venuePhone;
    }

    /**
     * @param venuePhone the venuePhone to set
     */
    public void setVenuePhone(String venuePhone) {
        this.venuePhone = venuePhone;
    }

    /**
     * @return the todayDate
     */
    public String getTodayDate() {
        return todayDate;
    }

    /**
     * @param todayDate the todayDate to set
     */
    public void setTodayDate(String todayDate) {
        this.todayDate = todayDate;
    }

    /**
     * @return the discoveryEndDate
     */
    public String getDiscoveryEndDate() {
        return discoveryEndDate;
    }

    /**
     * @param discoveryEndDate the discoveryEndDate to set
     */
    public void setDiscoveryEndDate(String discoveryEndDate) {
        this.discoveryEndDate = discoveryEndDate;
    }

    /**
     * @return the mailLine1
     */
    public String getMailLine1() {
        return mailLine1;
    }

    /**
     * @param mailLine1 the mailLine1 to set
     */
    public void setMailLine1(String mailLine1) {
        this.mailLine1 = mailLine1;
    }

    /**
     * @return the mailLine2
     */
    public String getMailLine2() {
        return mailLine2;
    }

    /**
     * @param mailLine2 the mailLine2 to set
     */
    public void setMailLine2(String mailLine2) {
        this.mailLine2 = mailLine2;
    }

    /**
     * @return the mailLine3
     */
    public String getMailLine3() {
        return mailLine3;
    }

    /**
     * @param mailLine3 the mailLine3 to set
     */
    public void setMailLine3(String mailLine3) {
        this.mailLine3 = mailLine3;
    }

    /**
     * @return the mailLine4
     */
    public String getMailLine4() {
        return mailLine4;
    }

    /**
     * @param mailLine4 the mailLine4 to set
     */
    public void setMailLine4(String mailLine4) {
        this.mailLine4 = mailLine4;
    }

    /**
     * @return the mailLine5
     */
    public String getMailLine5() {
        return mailLine5;
    }

    /**
     * @param mailLine5 the mailLine5 to set
     */
    public void setMailLine5(String mailLine5) {
        this.mailLine5 = mailLine5;
    }

    /**
     * @return the bodyLine1
     */
    public String getBodyLine1() {
        return bodyLine1;
    }

    /**
     * @param bodyLine1 the bodyLine1 to set
     */
    public void setBodyLine1(String bodyLine1) {
        this.bodyLine1 = bodyLine1;
    }

    /**
     * @return the bodyLine25
     */
    public String getBodyLine25() {
        return bodyLine25;
    }

    /**
     * @param bodyLine25 the bodyLine25 to set
     */
    public void setBodyLine25(String bodyLine25) {
        this.bodyLine25 = bodyLine25;
    }

    /**
     * @return the bodyLine69
     */
    public String getBodyLine69() {
        return bodyLine69;
    }

    /**
     * @param bodyLine69 the bodyLine69 to set
     */
    public void setBodyLine69(String bodyLine69) {
        this.bodyLine69 = bodyLine69;
    }

    /**
     * @return the caseTitle
     */
    public String getCaseTitle() {
        return caseTitle;
    }

    /**
     * @param caseTitle the caseTitle to set
     */
    public void setCaseTitle(String caseTitle) {
        this.caseTitle = caseTitle;
    }

    /**
     * @return the caseKey
     */
    public String getCaseKey() {
        return caseKey;
    }

    /**
     * @param caseKey the caseKey to set
     */
    public void setCaseKey(String caseKey) {
        this.caseKey = caseKey;
    }
    public Collection getAcmsDedData() {
        try {
            InputStream in = AcmsDed.class.getResourceAsStream( "DISCOV.TXT" );
            List<String> lines = IOUtils.readLines(in);
            if (lines != null) {
                List<AcmsDed> data = new ArrayList<AcmsDed>(lines.size());
                int index = 0;
                for (String line: lines) {
                    if (line != null && index > 0) {
                        data.add(formatAcmsDed(line, index++));
                    } else {
                        index++;
                    }
                }
                return data;
            }
        } catch (IOException ex) {
            Logger.getLogger(AcmsDed.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new ArrayList<AcmsDed>(1);
    }

    private AcmsDed formatAcmsDed(String line, int index) {
        String[] fields = line.split(";");
        AcmsDed ded = new AcmsDed();
        ded.setSeqNo(Integer.toString(index));
        ded.setVenueAddressLine1(fields[0]);
        ded.setVenueAddressLine2(fields[1]);
        ded.setVenueAddressLine3(fields[2]);
        ded.setVenueAddressLine4(fields[3]);
        ded.setVenuePhone(fields[4]);
        ded.setTodayDate(fields[5]);
        ded.setCaseTitle(fields[6]);
        ded.setCaseKey(fields[7]);
        ded.setBodyLine1(fields[8]);
        ded.setBodyLine25(fields[9]);
        ded.setBodyLine69(fields[10]);
        ded.setMailLine1(fields[11]);
        ded.setMailLine2(fields[12]);
        ded.setMailLine3(fields[13]);
        try {
            ded.setMailLine4(fields[14]);
        } catch (Exception e) {
            ded.setMailLine4("");
        }
        try {
            ded.setMailLine5(fields[15]);
        } catch (Exception e) {
            ded.setMailLine5("");
        }
        return ded;
    }    
}
