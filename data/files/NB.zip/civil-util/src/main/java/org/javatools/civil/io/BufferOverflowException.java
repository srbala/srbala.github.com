/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.javatools.io;

/**
 *
 * @author bob.reaman
 */
public class BufferOverflowException extends RuntimeException {
    public BufferOverflowException() {
        super();
    }
    public BufferOverflowException(String message) {
        super(message);
    }
}
