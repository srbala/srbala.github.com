#!/bin/sh
java -Xmx2048m -Xms1024m -jar JDataExtract.jar