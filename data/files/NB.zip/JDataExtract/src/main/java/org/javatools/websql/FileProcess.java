/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.javatools.websql;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOCase;
import org.apache.commons.io.filefilter.SuffixFileFilter;

import com.ibm.db2.jcc.am.SqlInvalidAuthorizationSpecException;

import org.javatools.headless.HeadlessMode;
import org.javatools.util.Status;
import org.javatools.view.*;

/**
 *
 * @author bsraman
 */
public class FileProcess {

	private static String inpDir;
	private static String outDir;
	private static ReadConfigProperties config;
	public static ArrayList<String> fileNames;
	public static ArrayList<ProcessInput> PIs;
	public static boolean rescan;
	public static Thread t;
	public static boolean badLogin;

	/**
	 * @param args the command line arguments
	 */
	public static void processInput(String input, String output, ReadConfigProperties c) {
		inpDir = input;
		outDir = output;
		config = c;
		File inputDir = new File(input);
		File outputDir = new File(output);
		fileNames = new ArrayList<String>();
		PIs = new ArrayList<ProcessInput>();
		rescan = false;
		badLogin = false;
		if (outputDir.isDirectory()) {
			try {
				Connection conn = getDBConnection();
				if (conn != null) {

					String[] allFiles = null;
					if (inpDir.endsWith(".sql") || inpDir.endsWith(".xls") || inpDir.endsWith(".xlsx")){
						allFiles = new String[1];
						allFiles[0] = inpDir.substring(inpDir.lastIndexOf("\\") + 1);
					} else {
						IOCase ioCase = IOCase.INSENSITIVE;
						List suffixList = new ArrayList();
						suffixList.add(".sql");
						suffixList.add(".xls");
						suffixList.add(".xlsx");
						allFiles = inputDir.list(new SuffixFileFilter(suffixList, ioCase));
					}

					if (processFileType(inputDir, conn, ".sql")) {
						MainView.log.info("FM0007: All SQL files processed");
					} else {
						MainView.log.info("FM0008: None of SQL files processed");
					}
					if (processFileType(inputDir, conn, ".xls")) {
						MainView.log.info("FM0005: All XLS files processed");
					} else {
						MainView.log.info("FM0006: None of XLS files processed");
					}
					if (processFileType(inputDir, conn, ".xlsx")) {
						MainView.log.info("FM0005: All XLSX files processed");
					} else {
						MainView.log.info("FM0006: None of XLSX files processed");
					}

					if (PIs.size() > 0){

						if (MainView.mainViewRun){	//GUI
							final ProgressMenu pm = new ProgressMenu(fileNames, PIs);
							Thread p = new Thread(pm);
							p.start();

							for (int i = 0; i < PIs.size(); i++){
								if (PIs.get(i).getProcessStatus().equals(Status.inQueue)){
									t = new Thread(PIs.get(i));
									PIs.get(i).setProcessStatus(Status.inProgress);
									pm.statusChange(i, Status.inProgress);
									t.start();
									try {
										t.join();
									} catch (InterruptedException e) {
										MainView.log.info("Thread failed to join.");
									}
									if (PIs.get(i).getProcessStatus().equals(Status.failed)){
										pm.statusChange(i, Status.failed);
									}
									else if (!PIs.get(i).getProcessStatus().equals(Status.cancelled)){
										PIs.get(i).setProcessStatus(Status.complete);
										pm.statusChange(i, Status.complete);
									}
								}
								if (rescan){
									rescan = false;
									i = -1;
								}
							}
							try {
								Thread.sleep(500);
							} catch(InterruptedException e) {

							}
							pm.pm.setVisible(false);
							pm.pm.dispose();
							pm.finished = true;

						} else {	//Headless
							for (int i = 0; i < PIs.size(); i++){
								if (PIs.get(i).getProcessStatus().equals(Status.inQueue)){
									t = new Thread(PIs.get(i));
									PIs.get(i).setProcessStatus(Status.inProgress);
									t.start();
									try {
										t.join();
									} catch (InterruptedException e) {
										MainView.log.info("Thread failed to join.");
									}
									if (!PIs.get(i).getProcessStatus().equals(Status.cancelled)){
										PIs.get(i).setProcessStatus(Status.complete);
									}
								}
							}
							try {
								Thread.sleep(500);
							} catch(InterruptedException e) {

							}
						}
						for (int i = 0; i < PIs.size(); i++){
							if (PIs.get(i).getProcessStatus().equals(Status.complete)) {
								MainView.log.info("FM0009.2: Input file " + fileNames.get(i) + " processed sucessfully");
							} else if(PIs.get(i).getProcessStatus().equals(Status.cancelled)) {
								MainView.log.info("FM0010.2: Input file " + fileNames.get(i) + " was cancelled");
							} else {
								MainView.log.info("FM0010.2: Input file " + fileNames.get(i) + " processed failed");
							}
						}
					}

					// Close database connection after process
					DbUtils.close(conn);

				} else if (badLogin){
					MessageWindow.displayError("Incorrect username or passowrd");
					badLogin = false;
					MainView.success = false;
				} else {
					MainView.log.info("FM0011: Database Connection Failed");
					MainView.success = false;
				}
			} catch (ClassNotFoundException ex) {
				//Logger.getLogger(FileProcess.class.getName()).log(Level.SEVERE, null, ex);
				MessageWindow.displayError("Connection failed.");
				MainView.log.log(Level.SEVERE, ex.toString(), ex);
			}

		} else {
			MainView.log.info("FM0004: Invalid output directory location" + outputDir.toString());
		}
	}

	/**
	 * Establishes a connection with the DB the user provided a URL for in the MainView
	 * 
	 * @return
	 * @throws ClassNotFoundException
	 */
	public static Connection getDBConnection() throws ClassNotFoundException {
		try {
			Class.forName(config.getDriverName());
			String url = config.getUrl();
			String userid = config.getUsername();
			String passwd = config.getPassword();
			Connection conn = DriverManager.getConnection(url, userid, passwd);
			//Properties prop = conn.getClientInfo();
			DatabaseMetaData dm = conn.getMetaData();
			//System.out.println("KeyWords: " + dm.getSQLKeywords());
			//System.out.println("Str Functions: " + dm.getStringFunctions());
			//System.out.println("Sys Functions: " + dm.getSystemFunctions());
			//System.out.println("Dte Functions " + dm.getTimeDateFunctions());
			//System.out.println("Num Functions" + dm.getNumericFunctions());
			return conn;
		} catch (SqlInvalidAuthorizationSpecException e){
			badLogin = true;
		} catch (SQLException ex) {
			//Logger.getLogger(FileProcess.class.getName()).log(Level.SEVERE, null, ex);
			MainView.log.log(Level.SEVERE, ex.toString(), ex);
		} 
		return null;
	}

	/**
	 * Gets all of the files in the given input directory that match the given file type
	 * and creates a new ProcessInput object with each and adds that object to an array list
	 * 
	 * @param inputDir
	 * @param conn
	 * @param fileType
	 * @return
	 */
	public static boolean processFileType(File inputDir, Connection conn, String fileType) {
		IOCase ioCase = IOCase.INSENSITIVE;
		List suffixList = new ArrayList();
		suffixList.add(fileType);
		String[] files = inputDir.list(new SuffixFileFilter(suffixList, ioCase));

		//Single file
		if (inpDir.endsWith(fileType)) {
			String file = inpDir.substring(inpDir.lastIndexOf("\\") + 1);
			if (fileType.equalsIgnoreCase(".sql")){
				String sql = readSQL(inpDir);
				if (sql != null && sql.length() > 0){
					ProcessInput pi = new ProcessInput(sql, true, outDir + file, conn, config.getMainHeader(), config);
					fileNames.add(file);
					PIs.add(pi);
				}
			} else {
				ProcessInput pi = new ProcessInput(inpDir, false, outDir + file, conn, config.getMainHeader(), config);
				fileNames.add(file);
				PIs.add(pi);
			}
			return true;
		}

		//Directory
		else if (files != null) {

			if (fileType.equalsIgnoreCase(".sql")){
				String[] sql = new String[files.length];

				//get all variable names in sql files from user
				for (int i = 0; i < files.length; i++) {
					String temp = readSQL(inpDir + files[i]);
					if (temp != null && temp.length() > 0){
						sql[i] = temp;
					} else {
						sql[i] = null;
					}
				}

				//do processing of sql files
				for (int i = 0; i < files.length; i++){
					String outFile = outDir + files[i];
					if (sql[i] != null){
						ProcessInput pi = new ProcessInput(sql[i], true, outFile, conn, config.getMainHeader(), config);
						fileNames.add(files[i]);
						PIs.add(pi);
					}
				}

			} else {
				for (int i = 0; i < files.length; i++) {
					String inFile = inpDir + files[i];
					String outFile = outDir + files[i];
					ProcessInput pi = new ProcessInput(inFile, false, outFile, conn, config.getMainHeader(), config);
					fileNames.add(files[i]);
					PIs.add(pi);
				}
			}
			if (files.length == 0) {
				MainView.log.info("FM0001: No Matching input files found in directory : " + inputDir.toString());
				return false;
			}
			return true;
		} else {
			MainView.log.info("FM0002: May be an invalid file/directory or empty : " + inputDir.toString());
		}
		return false;
	}

	/**
	 * Stores the contents of the file represented by the given file path in a string,
	 * passes this string to variableCheck to get the variable values from the user, and 
	 * then returns this new string which represents the query with user given values
	 * replacing any variable names
	 * 
	 * @param inpFile
	 * @return
	 */
	public static String readSQL(String inpFile) {
		String sql;
		try {
			File file = new File(inpFile);
			String fis = FileUtils.readFileToString(file);
			if (fis != null) {
				sql = variableCheck(fis, inpFile);
				if (sql != null){
					return sql;
				}
			}
		} catch (IOException ex) {
			Logger.getLogger(ProcessInput.class.getName()).log(Level.SEVERE, null, ex);
		}
		return null;
	}


	/**
	 * Takes the given query, gets all of the variable names from it, and stores the names in an arraylist.
	 * Then passes this arraylist to DefineVariables.getVarValues and receives back a hash map that has the 
	 * user given values for each variable. The variables in the original string are replaces by their values
	 * and then this new string is returned.
	 * 
	 * @param fis
	 * @param inpFile
	 * @return
	 */
	public static String variableCheck(String fis, String inpFile){
		String newfis = "", value;
		ArrayList<String> vars = new ArrayList<>();

		//loop through once to get variable names
		for (int i = 0; i < fis.length(); i++){
			if (fis.charAt(i) == '&'){
				//get the variable name
				int sep = fis.indexOf("&", i + 1);
				String variable = fis.substring(i + 1, sep);
				i = sep;
				variable = variable.trim();
				if (!vars.contains(variable)){
					vars.add(variable);
				}
			}
		}

		if (vars.size() > 0){

			HashMap<String, String> values = new HashMap<>();

			//get variable names either from the user, or from the properties file
			if (MainView.mainViewRun){
				values = DefineVariables.getVarValues(vars, inpFile.substring(inpFile.lastIndexOf("\\") + 1));
			} else {
				values = propertiesVariables(vars);
			}
			System.out.println("hashmap: " + values);

			if (values != null && values.size() > 0){

				//loop through again to plug in variable values
				for (int i = 0; i < fis.length(); i++){
					if (fis.charAt(i) != '&'){
						newfis = newfis + fis.charAt(i);
					} else {

						//get the variable name
						int sep = fis.indexOf("&", i + 1);
						String variable = fis.substring(i + 1, sep);
						variable = variable.trim();

						//get variables value and add it to the SQL
						value = values.get(variable);
						newfis = newfis + value;
						i = sep;
					}
				}
			} else {
				MainView.log.info("Missing variable value(s) for " + inpFile.substring(inpFile.lastIndexOf("\\") + 1));
				return null;
			}
		} else {
			return fis;
		}
		System.out.println("New SQL:\n" + newfis + "\n");
		return newfis;
	}


	/**
	 * FOR HEADLESS MODE
	 * 
	 * Takes an array list of variable names as a parameter, pulls all of the variables values from
	 * a property file, and creates a hashmap of variables and values which is then returned.
	 * 
	 * @param al
	 * @return
	 */
	public static HashMap<String, String> propertiesVariables(ArrayList<String> al){
		Properties properties = new Properties();
		HashMap<String, String> hm = new HashMap<>();
		String value;

		//read variables properties file
		try {
			MainView.log.info("Reading in main Headless Mode property file...");
			properties.load(new FileInputStream(HeadlessMode.properties.getProperty("settings.variablesLocation")));
		} catch (IOException e) {
			return null;
		}

		//gets variable value from property file and adds the variable/value to the hashmap
		for (int i = 0; i < al.size(); i++){
			value = properties.getProperty(al.get(i));
			System.out.println("value: " + value);
			if (value != null && value.length() > 0){
				hm.put(al.get(i), value);
			}
		}

		//return the hashmap provided that it isn't empty
		if (hm != null && hm.size() > 0){
			return hm;
		}
		return null;
	}
}
