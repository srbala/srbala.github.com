package org.javatools.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.Properties;

import org.javatools.view.MainView;

/**
 * @author bob.reaman
 *
 */
public class MonthStartEnd {
	
	/**
	 * Get the first and last day of either the previous or current month
	 * 
	 * @param m (month)
	 * @param year
	 * @param flag (0 for previous month and 1 for current month)
	 */
	public static String[] getFirstLast(int m, int year, int flag){
		Calendar cal = Calendar.getInstance();
		int month = m;
		
		//check flag and set month accordingly
		if (flag == 0){
			cal.add(Calendar.MONTH, month);
		} else if (flag == 1){
			month++;
			cal.add(Calendar.MONTH, month);
		}
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.add(Calendar.DATE, -1);
		
		String first, last;
		int previousMonth;
		last = "" + year;
		first = "" + year;
		
		//get previous month
		if (month == 1){
			previousMonth = 12;
		} else {
			previousMonth = month - 1;
		}
		
		//add previous month to first and last day of month Strings
		if (previousMonth < 10){
			first = first + "0" + previousMonth;
			last = last + "0" + previousMonth;
		} else {
			first = first + previousMonth;
			last = last + previousMonth;
		}
		
		//add day to first day of month String
		first = first + "01";
		
		//add day to last day of month String
		last = last + cal.get(Calendar.DAY_OF_MONTH);
		
		//add month start and end dates to return array
		String[] array = new String[2];
		array[0] = first;
		array[1] = last;
		
		return array;
	}
	
	/**
	 * 
	 * 
	 * @param dates (String array containing the first and last dates of the month
	 */
	public static void outputDates(String[] dates, String outputLocation){
        
		 //load properties file for output
        Properties properties = new Properties();
        try {
            properties.load(new FileInputStream(outputLocation));
        } catch (IOException e) {
        	MainView.log.info("Unable to find properties file to write start and end dates to.");
        	return;
        }
        properties.setProperty("DATESTART", dates[0]);
        properties.setProperty("DATEEND", dates[1]);
        
        //write to the output properties file
    	try {
			properties.store(new FileOutputStream(outputLocation), "");
		} catch (IOException e) {
			MainView.log.info("Failed to save start and end dates to property file.");
		}
	}
	
	public static void getMonthStartEnd(String outputLocation){
		
		//get the current date
		Calendar currentDate = Calendar.getInstance();
		
		//get the day, month, and year individually
		int day, month, year;
		day = currentDate.get(Calendar.DAY_OF_MONTH);
		month = currentDate.get(Calendar.MONTH) + 1;
		year = currentDate.get(Calendar.YEAR);
		
		String[] dates = new String[2];
		if(day < 24){	//previous month
			dates = getFirstLast(month, year, 0);
		} else {	//current month
			dates = getFirstLast(month, year, 1);
		}
		
		outputDates(dates, outputLocation);
	}
}
