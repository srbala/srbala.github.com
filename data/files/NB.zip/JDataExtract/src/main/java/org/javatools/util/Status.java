package org.javatools.util;

public class Status {

	final public static String cancelled = "Cancelled";
	final public static String inProgress = "In progress";
	final public static String complete = "Completed";
	final public static String inQueue = "In queue";
	final public static String terminate = "Terminate";
	final public static String failed = "Failed";
}
