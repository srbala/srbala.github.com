package org.javatools.headless;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Properties;

import org.javatools.util.Encryption;
import org.javatools.util.MonthStartEnd;
import org.javatools.websql.FileProcess;
import org.javatools.websql.ReadConfigProperties;

/**
 * @author bob.reaman
 *
 */
public class HeadlessMode {

	public static Properties properties;
	public final static ReadConfigProperties config = ReadConfigProperties.getInstance();
	public static String inputDir, outputDir, outFileType;
	
	/**
	 * Reads in the main property file which contains all of the variables needed to run.
	 * 
	 * @param location (location of main property file)
	 * @return
	 */
	public static boolean readProperties(String location){
		
		if (location == null || location.length() < 1){
			return false;
		}
		
		//read Headless Mode properties file
        properties = new Properties();
        try {
        	System.out.println("Reading in main Headless Mode property file...");
            properties.load(new FileInputStream(location));
        } catch (IOException e) {
        	return false;
        }

		return true;
	}
	
	/**
	 * Reads in all variables needed from the main property file
	 */
	public static void loadVariables(){
		inputDir = properties.getProperty("settings.inputDir");
		outputDir = properties.getProperty("settings.outputDir");
		config.setPassword(properties.getProperty("login.password"));
		outFileType = properties.getProperty("settings.outputType");
		String db = properties.getProperty("settings.database");
		
		String KEY = "";
		boolean keyCreated = false;
		
		//create key for decoding
		try {
			KEY = Encryption.buildKey(new String(Base64.getDecoder().decode(properties.getProperty("login.username"))).trim());
			if (KEY != null){
				keyCreated = true;
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		//decode user name and password
		if (keyCreated){
			try {
				config.setUsername(new String(Base64.getDecoder().decode(properties.getProperty("login.username"))).trim());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				config.setPassword(new String(Encryption.decrypt(Base64.getDecoder().decode(properties.getProperty("login.password")), KEY)).trim());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		String url = "";
		if (db.compareTo("DB2P") == 0){
			url = "jdbc:db2://172.16.1.27:5025/DB2P";
		}
		else if (db.compareTo("DB14") == 0){
			url = "jdbc:db2://172.16.1.27:5042/DB14";
		}
		else if (db.compareTo("DB2D") == 0){
			url = "jdbc:db2://172.16.1.27:446/DB2D";
		}
		else if (db.compareTo("DBWP") == 0){
			url = "jdbc:db2://172.16.1.27:5036/DBWP";
		}
		else if (db.compareTo("DB2T") == 0){
			url = "jdbc:db2://172.16.1.27:5021/DB2T";
		}
		else if (db.compareTo("DB2P") == 0){
			url = "jdbc:db2://172.16.1.27:5025/DB2P";
		}
		else if (db.compareTo("DBWD") == 0){
			url = "jdbc:db2://172.16.1.27:5034/DBWD";
		}
		else if (db.compareTo("DBWT") == 0){
			url = "jdbc:db2://172.16.1.27:5031/DBWT";
		}
		config.setUrl(url);
	}
	
	public static void main(String[] args){
		System.out.println("JDataExtract Headless Mode starting...");
		if (readProperties(args[0])){
			loadVariables();
			MonthStartEnd.getMonthStartEnd(properties.getProperty("settings.monthlyRunLocation"));
			FileProcess.processInput(inputDir, outputDir, config);
		} else {
			System.out.println("Unable to read properties file(s).");
		}
	}
}
