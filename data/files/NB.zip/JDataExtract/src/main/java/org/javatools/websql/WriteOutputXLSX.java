/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.javatools.websql;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.javatools.view.MainView;

/**
 *
 * @author bsraman
 */
public class WriteOutputXLSX {

    private String outputFileWithPath;
    private String title;
    private ResultSet rs;
    private String sqlString;
    private List<String> columnNames = new ArrayList<String>();
    private List<String> columnTypes = new ArrayList<String>();
    private boolean processStatus;
    private String columnHeaderColor, bodyColor;

    private WriteOutputXLSX() {
    }

    public WriteOutputXLSX(ResultSet rs, String outputFileWithPath, String title, String sqlString,
    		String chc, String bc) {
        this.outputFileWithPath = outputFileWithPath;
        this.columnHeaderColor = chc;
        this.bodyColor = bc;
        this.rs = rs;
        this.title = title;
        this.sqlString = sqlString;
        processOutput();
    }

    public void processOutput() {
        // Write the output to a file
        processStatus = false;
        boolean csv = false;
        File tempFile = null;
        try {
        	//System.out.println("output: " + getOutputFileWithPath());
        	if (getOutputFileWithPath().endsWith("csv")){
        		tempFile = File.createTempFile("temp", ".xlsx");
        		csv = true;
        	}
            if (getTitle() == null) {
            	if (csv){
            		setTitle("temp");
            	} else {
            		File file = new File(getOutputFileWithPath());
            		setTitle(file.getName());
            	}
            }
            XSSFWorkbook wb = new XSSFWorkbook();
            generateDataSheet(wb);
            generateSqlSheet(wb);
            FileOutputStream fileOut;
            if (csv){
            	fileOut = new FileOutputStream(tempFile);
        	} else {
        		fileOut = new FileOutputStream(getOutputFileWithPath());
        	}
            wb.write(fileOut);
            fileOut.close();
            processStatus = true;
            if (csv){
            	XLSXtoCSV.xlsx(tempFile, getOutputFileWithPath());
            	tempFile.delete();
            }

        } catch (FileNotFoundException ex) {
            //Logger.getLogger(ProcessInput.class.getName()).log(Level.SEVERE, null, ex);
        	MainView.log.log(Level.SEVERE, ex.toString(), ex);
        } catch (IOException ex) {
            //Logger.getLogger(ProcessInput.class.getName()).log(Level.SEVERE, null, ex);
        	MainView.log.log(Level.SEVERE, ex.toString(), ex);
        }
    }

    public void generateDataSheet(XSSFWorkbook wb) {
        XSSFSheet sheet = wb.createSheet("DATA");
        try {
            boolean titleStatus = getTableHeader(wb, sheet, 2);
            if (titleStatus) {
                titleStatus = getTableData(wb, sheet, 3);
            }
            for (short index = 0; index < columnTypes.size(); index++) {
                sheet.autoSizeColumn(index);
            }
            XSSFRow row = sheet.createRow((short) 0);
            XSSFFont font = wb.createFont();
            font.setFontHeightInPoints((short) 16);
            font.setBold(true);
            XSSFCellStyle style = wb.createCellStyle();
            style.setFont(font);
            XSSFRichTextString textString = new XSSFRichTextString(getTitle());
            XSSFCell title1 = row.createCell((short) 0);
            title1.setCellValue(textString);
            title1.setCellStyle(style);
            XSSFRow row1 = sheet.createRow((short) 1);
            File fs = new File(this.outputFileWithPath);
            String title2str = fs.getName();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.S'000'");
            title2str = title2str.substring(0, (title2str.length() - 4)) + " (" + sdf.format(new Date()) + ")";
            XSSFRichTextString textString1 = new XSSFRichTextString(title2str);
            font.setFontHeightInPoints((short) 12);
            XSSFCell title2 = row1.createCell((short) 0);
            title2.setCellValue(textString1);
            title2.setCellStyle(style);
            sheet.createFreezePane(0, 3, 0, 3);
        } catch (SQLException ex) {
            //Logger.getLogger(WriteOutputXLS.class.getName()).log(Level.SEVERE, null, ex);
        	MainView.log.log(Level.SEVERE, ex.toString(), ex);
        }
    }

    public void generateSqlSheet(XSSFWorkbook wb) {
        if (getSqlString() == null) {
            setSqlString("SQL Statement not found");
        }
        XSSFSheet sheet = wb.createSheet("SQL Statement");
        XSSFRow row = sheet.createRow((short) 0);
        XSSFRichTextString textString = new XSSFRichTextString("SQL Statement");
        XSSFCell title1 = row.createCell((short) 0);
        title1.setCellValue(textString);
        XSSFRow row1 = sheet.createRow((short) 1);
        XSSFRichTextString textString1 = new XSSFRichTextString(getSqlString());
        row1.createCell((short) 0).setCellValue(textString1);
    }

    public boolean getTableHeader(XSSFWorkbook wb, XSSFSheet sheet, int rownum)
            throws SQLException {
        if (getRs() == null) {
            return false;
        }
        XSSFRow row = sheet.createRow((short) rownum);
        columnNames.clear();
        columnTypes.clear();


        // get result set meta data
        ResultSetMetaData rsMetaData = getRs().getMetaData();
        int numberOfColumns = rsMetaData.getColumnCount();
        XSSFCellStyle style = wb.createCellStyle();
        
        //set color for column header
        if (columnHeaderColor.equals("Aqua")){
        	style.setFillForegroundColor(IndexedColors.AQUA.getIndex());
        } else if (columnHeaderColor.equals("Gray")){
        	style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        } else if (columnHeaderColor.equals("Green")){
        	style.setFillForegroundColor(IndexedColors.BRIGHT_GREEN.getIndex());
        } else if (columnHeaderColor.equals("Orange")){
        	style.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.getIndex());
        } else if (columnHeaderColor.equals("Yellow")){
        	style.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
        }
        
        if (!columnHeaderColor.equals("None")){
            style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        }
        
        XSSFFont font = wb.createFont();
        font.setBold(true);
        style.setFont(font);

        // get the column names; column indexes start from 1
        for (short index = 0; index < numberOfColumns; index++) {
            String columnName = rsMetaData.getColumnName(index + 1);
            columnNames.add(columnName);
            String columnType = rsMetaData.getColumnTypeName(index + 1);
            columnTypes.add(columnType);
            XSSFRichTextString textString = new XSSFRichTextString(columnName);
            XSSFCell cell = row.createCell(index);
            cell.setCellValue(textString);
            cell.setCellStyle(style);
            sheet.autoSizeColumn(index);
        }

        return true;
    }

    public boolean getTableData(XSSFWorkbook wb, XSSFSheet sheet, int rownum)
            throws SQLException {
        if (rs == null) {
            return false;
        }

        int numberOfColumns = columnNames.size();

        XSSFCellStyle dateStyle = wb.createCellStyle();
        XSSFDataFormat format = wb.createDataFormat();
        dateStyle.setDataFormat(format.getFormat("YYYY/MM/DD"));
        // get the column names; column indexes start from 1
        int recNumber = 0;
        
        CellStyle style = wb.createCellStyle();
        style = wb.createCellStyle();
        
        //set color for body
        if (bodyColor.equals("Aqua")){
        	style.setFillForegroundColor(IndexedColors.AQUA.getIndex());
        } else if (bodyColor.equals("Gray")){
        	style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        } else if (bodyColor.equals("Green")){
        	style.setFillForegroundColor(IndexedColors.BRIGHT_GREEN.getIndex());
        } else if (bodyColor.equals("Orange")){
        	style.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.getIndex());
        } else if (bodyColor.equals("Yellow")){
        	style.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
        }
   
        if (!bodyColor.equals("None")){
            style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        }
        
        int rowCount = 0;
        
        while (rs.next()) {
            recNumber = recNumber + 1;
            XSSFRow row = sheet.createRow((short) rownum++);
            for (short index = 0; index < numberOfColumns; index++) {
                if (!columnTypes.get(index).equals("DATE")) {
                    String columnData = getRs().getString(index + 1);
                    if (columnData == null) {
                        columnData = "";
                    }
                    XSSFRichTextString textString = new XSSFRichTextString(columnData);
                    row.createCell(index).setCellValue(textString);
                    if (rowCount % 2 != 0){
                    	row.getCell(index).setCellStyle(style);
                    }
                } else {
                    Date columnData = getRs().getDate(index + 1);
                    if (columnData == null) {
                        columnData = new Date();
                    }
                   XSSFCell cell = row.createCell(index);
                    cell.setCellValue(columnData);
                    cell.setCellStyle(dateStyle);
                }
            }
            rowCount++;
            if (recNumber > 95000) {
                MainView.log.info("FM0201: File " + outputFileWithPath + " has more then 95 Records; only 95 Records written to out file");
                break;
            }

        }
        if (recNumber == 0) {
            MainView.log.info("FM0202: File " + outputFileWithPath + " has ZERO records in out file");
        }
        
        return true;
    }

    /**
     * @return the outputFileWithPath
     */
    private String getOutputFileWithPath() {
        return outputFileWithPath;
    }

    /**
     * @param outputFileWithPath the outputFileWithPath to set
     */
    private void setOutputFileWithPath(String outputFileWithPath) {
        this.outputFileWithPath = outputFileWithPath;
    }

    /**
     * @return the title
     */
    private String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    private void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the rs
     */
    private ResultSet getRs() {
        return rs;
    }

    /**
     * @param rs the rs to set
     */
    private void setRs(ResultSet rs) {
        this.rs = rs;
    }

    /**
     * @return the sqlString
     */
    private String getSqlString() {
        return sqlString;
    }

    /**
     * @param sqlString the sqlString to set
     */
    private void setSqlString(String sqlString) {
        this.sqlString = sqlString;
    }

    /**
     * @return the processStatus
     */
    public boolean isProcessStatus() {
        return processStatus;
    }
}
