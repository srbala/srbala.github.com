/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.javatools.websql;

import java.io.Console;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import org.javatools.view.MainView;

/**
 *
 * @author Bob.Reaman
 */
public class ReadConfigProperties {

    private static ReadConfigProperties instance;
    private static String driverName;
    private static String url;
    private static String username;
    private static String password;
    private static String maxCount;
    private static String title;
    private static String subtitle;
    private static String DB;
    private static String outputType;
    private static String logLoc;
    private static String outputDir;
    private static String mainHeader;
    private static String subHeader;
    private static String columnHeaderColor;
    private static String bodyColor;
    private static Properties properties;
    private static String propertiesLocation = "properties/database.properties";

    private ReadConfigProperties() {
    }

    /**
     * Loads the properties file
     * 
     * @return
     */
    public static ReadConfigProperties getInstance() {
        if (instance != null) {
            return instance;
        } else {
            
            // Read properties file.
            properties = new Properties();
            try {
                MainView.log.info("FM0901: Reading Config file database.properties from config directory");
                properties.load(new FileInputStream(propertiesLocation));
                readDBInfo(properties);
                getSettings(properties);
                MainView.log.info("FM0905: Config file read complete");
            } catch (IOException e) {
            	MainView.log.info("FM0902: Unable to find Config file database.properties in config directory");
                try {
                	MainView.log.info("FM0903: Reading Config file database.properties from current directory");
                    properties.load(new FileInputStream("database.properties"));
                    readDBInfo(properties);
                    MainView.log.info("FM0905: Config file read complete");
                } catch (IOException ie) {
                	MainView.log.info("FM0904: Unable to read config file");
                    properties = null;
                }
            }
            if (properties != null) {
            	instance = new ReadConfigProperties();
                return instance;
            } else {
                return null;
            }
        }

    }

    /**
     * @return the driverName
     */
    public String getDriverName() {
        return driverName;
    }

    /**
     * @param driverName the driverName to set
     */
    public static void setDriverName(String driverName1) {
        driverName = driverName1;
    }
    
    /**
     * @param save driverName to settings
     */
    public static void saveDriverName(String driverName1) {
    	driverName = driverName1;
        properties.setProperty("db.driver", driverName1);
    }

    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }

    /**
     * @param url the url to set
     */
    public void setUrl(String url1) {
        url = url1;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username1) {
        username = username1;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password1) {
        password = password1;
    }

    /**
     * @return the maxCount
     */
    public String getMaxCount() {
        return maxCount;
    }

    /**
     * @param maxCount the maxCount to set
     */
    public static void setMaxCount(String maxCount1) {
        maxCount = maxCount1;
    }
    
    
    private static void readDBInfo(Properties properties) {
        setDriverName(properties.getProperty("db.driver"));
        setMaxCount(properties.getProperty("db.maxcount"));
        setTitle(properties.getProperty("report.title"));
        setSubtitle(properties.getProperty("report.subtitle"));
    }
    
    /**
     * Gets all of the default settings from the properties file
     * 
     * @param properties
     */
    private static void getSettings(Properties properties){
    	setDB(properties.getProperty("settings.database"));
    	setOutputType(properties.getProperty("settings.outputType"));
    	setLogLocation(properties.getProperty("settings.logLocation"));
    	setOutputDir(properties.getProperty("settings.outputDir"));
    	setMainHeader(properties.getProperty("settings.mainHeader"));
    	setSubHeader(properties.getProperty("settings.subHeader"));
    	setColumnHeaderColor(properties.getProperty("settings.columnHeaderColor"));
    	setBodyColor(properties.getProperty("settings.bodyColor"));
    }
    
    @Override
    public Object clone()
            throws CloneNotSupportedException {
        throw new CloneNotSupportedException();
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param aTitle the title to set
     */
    public static void setTitle(String aTitle) {
        title = aTitle;
    }

    /**
     * @return the subtitle
     */
    public String getSubtitle() {
        return subtitle;
    }

    /**
     * @param aSubtitle the subtitle to set
     */
    public static void setSubtitle(String aSubtitle) {
        subtitle = aSubtitle;
    }
    
    /**
     * @return the DB
     */
    public String getDB() {
        return DB;
    }
    
    /**
     * @param set aDB to the DB
     */
    public static void setDB(String aDB) {
        DB = aDB;
    }
    
    /**
     * @param save aDB to the default DB
     */
    public static void saveDB(String aDB) {
    	DB = aDB;
        properties.setProperty("settings.database", aDB);
    }
    
    /**
     * @return the output type
     */
    public String getOutputType() {
        return outputType;
    }
    
    /**
     * @param set aOutputType to the output type
     */
    public static void setOutputType(String aOutputType) {
        outputType = aOutputType;
    }
    
    /**
     * @param save aOutputType to the default output type
     */
    public static void saveOutputType(String aOutputType) {
    	outputType = aOutputType;
        properties.setProperty("settings.outputType", aOutputType);
    }
    
     /**
     * @return the log file location
     */
    public String getLogLocation() {
        return logLoc;
    }

    /**
     * @param set aLogLoc to the log file location
     */
    public static void setLogLocation(String aLogLoc) {
        logLoc = aLogLoc;
    }
    
    /**
     * @param save aLogLoc to the default log file location
     */
    public static void saveLogLocation(String aLogLoc) {
    	logLoc = aLogLoc;
        properties.setProperty("settings.logLocation", aLogLoc);
    }
    
    /**
     * @return the output directory
     */
    public String getOutputDir() {
        return outputDir;
    }

    /**
     * @param set aOutputDir to the  output directory
     */
    public static void setOutputDir(String aOutputDir) {
        outputDir = aOutputDir;
    }
    
    /**
     * @param save aOutputDir to the default output directory
     */
    public static void saveOutputDir(String aOutputDir) {
        outputDir = aOutputDir;
        properties.setProperty("settings.outputDir", aOutputDir);
    }
    
    /**
     * @return the main header
     */
    public String getMainHeader() {
        return mainHeader;
    }

    /**
     * @param set aMainHeader to the main header
     */
    public static void setMainHeader(String aMainHeader) {
        mainHeader = aMainHeader;
    }
    
    /**
     * @param save aMainHeader to the default main header
     */
    public static void saveMainHeader(String aMainHeader) {
        mainHeader = aMainHeader;
        properties.setProperty("settings.mainHeader", aMainHeader);
    }
    
    
    /**
     * @return the main header
     */
    public String getSubHeader() {
        return subHeader;
    }

    /**
     * @param set aSubHeader to the sub header
     */
    public static void setSubHeader(String aSubHeader) {
        subHeader = aSubHeader;
    }
    
    /**
     * @param save aSubHeader to the default sub header
     */
    public static void saveSubHeader(String aSubHeader) {
        subHeader = aSubHeader;
        properties.setProperty("settings.subHeader", aSubHeader);
    }
    
    /**
     * @return the column header color
     */
    public String getColumnHeaderColor() {
        return columnHeaderColor;
    }

    /**
     * @param set aColumnHeaderColor to the column header color
     */
    public static void setColumnHeaderColor(String aColumnHeaderColor) {
        columnHeaderColor = aColumnHeaderColor;
    }
    
    /**
     * @param save aColumnHeaderColor to the default column header color
     */
    public static void saveColumnHeaderColor(String aColumnHeaderColor) {
        columnHeaderColor = aColumnHeaderColor;
        properties.setProperty("settings.columnHeaderColor", aColumnHeaderColor);
    }
    
    /**
     * @return the body color
     */
    public String getBodyColor() {
        return bodyColor;
    }

    /**
     * @param set aBodyColor to the body color
     */
    public static void setBodyColor(String aBodyColor) {
        bodyColor = aBodyColor;
    }
    
    /**
     * @param save aBodyColor to the default body color
     */
    public static void saveBodyColor(String aBodyColor) {
        bodyColor = aBodyColor;
        properties.setProperty("settings.bodyColor", aBodyColor);
    }
    
    public void saveSettings(){
    	try {
			properties.store(new FileOutputStream(propertiesLocation), "");
		} catch (IOException e) {
			System.out.println("Failed to save");
		}
    }
}
