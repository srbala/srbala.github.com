package org.javatools.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.javatools.websql.*;


/**
 * @author bob.reaman
 *
 */
public class MainView2 extends JFrame {

	private static final long serialVersionUID = 1L;
	static JFrame ui;
	static JLabel headerPic0, headerPic1;
	static JPanel panel, header, info, buttons, tablePanel;
	static JLabel driverL, urlL, userNameL, passwordL, outputL, outTypeL;
	static JTextField driverTF, userNameTF, passwordTF, outputTF;
	static JComboBox<String> urlMenu, outTypeTF;
	static JButton add, clear, exit, submit;
	public static JTable table;
	public static DefaultTableModel model;
	static JFileChooser fc;
	public final static ReadConfigProperties config = ReadConfigProperties.getInstance();
	
	JScrollPane scroll;
	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	String[] urls = {"DB2D", "DB2P", "DB14", "DBWP"};
	String[] fileTypes = {"xlsx", "xls", "csv"};

	public static String driver, userName, password, url, inputDir, outputDir, outFileType;

	public MainView2(String title){
		super(title);
		
		buildHeader();
		buildTable();
		buildInfoPanel();
		buildButtonPanel();

		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.add(header);
		outputL = new JLabel("Default Output Directory");
		outputTF = new JTextField();
		outputTF.setText("C:\\RSA9\\JudgementLien\\JDataExtract\\output");
		outputTF.setPreferredSize(new Dimension(300, 20));
		panel.add(outputL);
		panel.add(outputTF);
		panel.add(tablePanel);
		panel.add(info);
		panel.add(buttons);
		add(panel);
		pack();
	}

	public void buildHeader(){
		header = new JPanel();
		header.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(0, Math.round((float)screenSize.width * (float)0.197), 0, Math.round((float)screenSize.width * (float)0.194));
		header.setSize(new Dimension(this.getWidth(), this.getHeight()));
		ImageIcon icon0 = new ImageIcon(getClass().getResource("/img/statelogo.png"));
		ImageIcon icon1 = new ImageIcon(getClass().getResource("/img/header3.gif"));
		headerPic0 = new JLabel();
		headerPic0.setIcon(icon0);
		header.add(headerPic0, gbc);
		gbc.gridx++;
		headerPic1 = new JLabel();
		headerPic1.setIcon(icon1);
		header.add(headerPic1, gbc);
		header.setBackground(Color.WHITE);
	}
	
	public void buildTable(){
		tablePanel = new JPanel();
		tablePanel.setBackground(Color.WHITE);
		scroll = new JScrollPane();
		table = new JTable();
		Dimension tableD = new Dimension(screenSize.width - 60, 47);
		scroll.setViewportView(table);
		String[] columnNames = {"Input Directory", "Output Directory"}; 

		model = new DefaultTableModel(null, columnNames){
			private static final long serialVersionUID = 1L;

			@Override
			public boolean isCellEditable(int row, int column){  
				return column == 1;  
			}
		};

		table.setModel(model);
		table.setMinimumSize(tableD);
		table.setPreferredSize(tableD);
		table.setRowHeight(25);
		scroll.setMinimumSize(tableD);
		scroll.setPreferredSize(tableD);
		tablePanel.add(scroll);
	}

	public void buildInfoPanel(){
		info = new JPanel();
		info.setBackground(Color.WHITE);
		driverL = new JLabel("Driver *");
		driverTF = new JTextField();
		driverTF.setText("com.ibm.db2.jcc.DB2Driver");
		Dimension d = new Dimension(200, 20);
		driverTF.setPreferredSize(d);
		urlL = new JLabel("Url *");
		urlMenu = new JComboBox<>(urls);
		outTypeL = new JLabel("Output File Type *");
		outTypeTF = new JComboBox<String>(fileTypes);
		userNameL = new JLabel("User Name *");
		userNameTF = new JTextField();
		userNameTF.setPreferredSize(d);
		passwordL = new JLabel("Password *");
		passwordTF = new JPasswordField();
		passwordTF.setPreferredSize(d);
		info.add(driverL);
		info.add(driverTF);
		info.add(urlL);
		info.add(urlMenu);
		info.add(outTypeL);
		info.add(outTypeTF);
		info.add(userNameL);
		info.add(userNameTF);
		info.add(passwordL);
		info.add(passwordTF);
	}

	public void buildButtonPanel(){
		buttons = new JPanel();
		buttons.setBackground(Color.WHITE);
		add = new JButton("Add");
		clear = new JButton("Clear");
		clear.setEnabled(false);
		submit = new JButton("Submit");
		submit.setEnabled(false);
		exit = new JButton("Exit");
		
		add.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				//Set up file chooser
				fc = new JFileChooser("C:\\");
				fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				fc.setMultiSelectionEnabled(false);
				
				if (fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
					inputDir = fc.getSelectedFile().getAbsolutePath() + "\\";
					model.setRowCount(0);
					if (outputTF.getText().length() != 0){
						outputDir = outputTF.getText();
						if (!outputDir.endsWith("\\")){
							outputDir = outputDir + "\\";
						}
					}
					model.addRow(new Object[] {inputDir, outputDir});
					enableButtons();
				}
			}
		});
		
		clear.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				cellEditCheck();
				model.setRowCount(0);
				disableButtons();
			}
		});
		

		exit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(DISPOSE_ON_CLOSE);
			}
		});

		submit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				disableAllButtons();
				
				final ProgressBar pb = new ProgressBar();
				Thread p = new Thread(pb);
				p.start();
				
				inputDir = table.getValueAt(0, 0).toString();
				outputDir = table.getValueAt(0, 1).toString();
				driver = driverTF.getText();
				userName = userNameTF.getText();
				String temp = (String)urlMenu.getSelectedItem();
				password = passwordTF.getText();
				outFileType = (String)outTypeTF.getSelectedItem();
				if (temp.compareTo("DB2P") == 0){
					url = "jdbc:db2://172.16.1.27:5025/DB2P";
 				}
				else if (temp.compareTo("DB14") == 0){
					url = "jdbc:db2://172.16.1.27:5042/DB14";
				}
				else if (temp.compareTo("DB2D") == 0){
					url = "jdbc:db2://172.16.1.27:446/DB2D";
				}
				else if (temp.compareTo("DBWP") == 0){
					url = "jdbc:db2://172.16.1.27:5036/DBWP";
				}
				if (outputDir.equalsIgnoreCase("") || password.equalsIgnoreCase("") || userName.equalsIgnoreCase("")){
					MessageWindow.displayError("Please complete all required fields");
				} else {
					
					Thread t = new Thread(new Runnable(){
						@Override
						public void run() {
							FileProcess.processInput(inputDir, outputDir, config);
							add.setEnabled(true);
							pb.finished = true;
							model.setRowCount(0);
							disableButtons();
							pb.finished = true;
							MessageWindow.displayMessage("Process is complete.");
						}});
					t.start();
				}
			}
		});

		buttons.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(0, 10, 0, 0);
		buttons.add(add, gbc);
		gbc.gridx++;
		buttons.add(clear, gbc);
		gbc.gridx++;
		buttons.add(submit, gbc);
		gbc.gridx++;
		buttons.add(exit, gbc);
	}
	
	public static void cellEditCheck(){
		if (table.isEditing()) {
		    table.getCellEditor().stopCellEditing();
		}
	}
	
	public void disableButtons(){
		add.setEnabled(true);
		clear.setEnabled(false);
		submit.setEnabled(false);
		exit.setEnabled(true);
	}
	
	public void disableAllButtons(){
		add.setEnabled(false);
		clear.setEnabled(false);
		submit.setEnabled(false);
		exit.setEnabled(false);
	}
	
	public void enableButtons(){
		add.setEnabled(false);
		clear.setEnabled(true);
		submit.setEnabled(true);
	}

	public static void main(String[] args){
		ui = new MainView2("New Jersey Judiciary");
		ui.setExtendedState(Frame.MAXIMIZED_BOTH);
		ui.setLocationRelativeTo(null);
		ui.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		ui.setVisible(true);
	}
}
