package org.javatools.view;

import javax.swing.JOptionPane;

/**
 * @author bob.reaman
 *
 */
public class MessageWindow {
	
	/**
	 * Displays the given error message to the user
	 * 
	 * @param error
	 */
	public static void displayError(String error){
		JOptionPane.showMessageDialog(null, error, "Error", JOptionPane.ERROR_MESSAGE);
	}
	
	/**
	 * Displays the given message to the user
	 * 
	 * @param message
	 */
	public static void displayMessage(String message){
		JOptionPane.showMessageDialog(null, message, "New Jersey Judiciary", JOptionPane.PLAIN_MESSAGE);
	}
}
