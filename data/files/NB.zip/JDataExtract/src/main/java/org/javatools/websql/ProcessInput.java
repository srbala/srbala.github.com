/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.javatools.websql;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;

import com.ibm.db2.jcc.am.ClientRerouteException;
import com.ibm.db2.jcc.am.DisconnectNonTransientConnectionException;
import com.ibm.db2.jcc.am.SqlNonTransientConnectionException;

import org.javatools.headless.HeadlessMode;
import org.javatools.util.Status;
import org.javatools.view.MainView;

/**
 *
 * @author bsraman
 */
public class ProcessInput implements Runnable {

	private String sql;
	public Connection conn;
	private String outFile;
	private String outFile2;
	private String inpFile;
	private String fileType;
	private String title;
	private boolean status;
	public boolean prevCancel;
	private boolean SQL;
	private String outFileType;
	private ReadConfigProperties config;
	public String processStatus;
	public Statement stmt;

	public ProcessInput(String inputFile, boolean SQL, String outputFile, Connection conn, 
			String title, ReadConfigProperties c) {
		this.processStatus = Status.inQueue;
		this.title = title;
		this.conn = conn;
		this.config = c;
		this.SQL = SQL;
		this.inpFile = inputFile.trim();
		this.outFile = outputFile;
		this.outFile2 = outputFile;
		this.outFileType = MainView.outFileType;
		if(this.outFileType == null){
			this.outFileType = HeadlessMode.outFileType;
		}
		this.fileType = inpFile.substring((inpFile.length() - 3), inpFile.length());
	}

	/**
	 * Creates the new output file name, then calls the appropriate method to generate 
	 * the output file.
	 */
	public void generateOutput(){

			try {
				if (conn.isClosed()){
					MainView.log.info("The connection was closed unexpectedly and needs to be reopened.");
					openConnection();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 


		if (this.fileType.equalsIgnoreCase("xls")) {
			if (this.outFileType.equalsIgnoreCase("xls")){
				this.outFile = this.outFile2.substring(0,(outFile2.length() - 4)) + ".xls";
			} else if (this.outFileType.equalsIgnoreCase("csv")) {
				this.outFile = this.outFile2.substring(0,(outFile2.length() - 4)) + ".csv";
			} else {
				this.outFile = this.outFile2.substring(0,(outFile2.length() - 4)) + ".xlsx";
			}
			this.status = readXLS();
		} else if (this.fileType.equalsIgnoreCase("lsx")){
			if (this.outFileType.equalsIgnoreCase("xls")){
				this.outFile = this.outFile2.substring(0,(outFile2.length() - 5)) + ".xls";
			} else if (this.outFileType.equalsIgnoreCase("csv")) {
				this.outFile = this.outFile2.substring(0,(outFile2.length() - 5)) + ".csv";
			} else {
				this.outFile = this.outFile2.substring(0,(outFile2.length() - 5)) + ".xlsx";
			}
			this.status = readXLSX();
		} else if (SQL) {
			if (this.outFileType.equalsIgnoreCase("xls")){
				this.outFile = this.outFile2.substring(0,(outFile2.length() - 4)) + ".xls";
			} else if (this.outFileType.equalsIgnoreCase("csv")) {
				this.outFile = this.outFile2.substring(0,(outFile2.length() - 4)) + ".csv";
			} else {
				this.outFile = this.outFile2.substring(0,(outFile2.length() - 4)) + ".xlsx";
			}
			sql = inpFile;
			if (sql != null && !sql.equals("")){
				this.status = true;
			}
		} else {
			this.status = false;
		}
		if (status) {
			if (this.outFileType.equalsIgnoreCase("xls")){
				this.status = writeXLS(title);
			} else if (this.outFileType.equalsIgnoreCase("xlsx")){
				this.status = writeXLSX(title);
			}
			else if (this.outFileType.equalsIgnoreCase("csv")){
				try {
					ResultSet rset = getResultSet(conn);
					if (rset != null) {
						WriteOutputXLSX of = new WriteOutputXLSX(rset, this.outFile, title, sql, 
								config.getColumnHeaderColor(), config.getBodyColor());
						if (of.isProcessStatus()) {
							//System.out.println("File " + outFile + "Completed sucessfully ...!");
						}
						DbUtils.close(rset);
					}

				} catch (SQLException ex) {
					//Logger.getLogger(ProcessInput.class.getName()).log(Level.SEVERE, null, ex);
					if (!getProcessStatus().equals(Status.cancelled)){
						setProcessStatus(Status.failed);
					}
					MainView.log.log(Level.SEVERE, ex.toString(), ex);
				} catch (Exception ex) {
					//Logger.getLogger(ProcessInput.class.getName()).log(Level.SEVERE, null, ex);
					if (!getProcessStatus().equals(Status.cancelled)){
						setProcessStatus(Status.failed);
					}
					MainView.log.log(Level.SEVERE, ex.toString(), ex);
				}
			}
		}
	}


	public ProcessInput(String inputSQL, String outFile, Connection conn, String title, 
			boolean stats, ReadConfigProperties c) {

		/* Original Code
    	this.conn = conn;
        this.inpFile = null;
        this.outFile = outFile + ".xls";
        this.status = stats;
        if (status) {
            this.status = writeXLS(title);
        } */

		this.conn = conn;
		this.inpFile = null;
		this.status = stats;
		if (this.outFileType.equalsIgnoreCase("xls")){
			this.outFile = outFile + ".xls";
			if (status) {
				this.status = writeXLS(title);
			}
		} else {
			this.outFile = outFile + ".xlsx";
			if (status) {
				this.status = writeXLSX(title);
			}
		}
	}
	
	/**
	 * @return the current processStatus
	 */
	public boolean isProcessSucess() {
		return this.status;
	}

	/**
	 * Writes the results to an XLS file
	 * 
	 * @param title
	 * @return
	 */
	private boolean writeXLS(String title) {
		try {
			ResultSet rset = getResultSet(conn);
			if (rset != null) {
				//System.out.println("outFile: " + outFile);
				WriteOutputXLS of = new WriteOutputXLS(rset, outFile, title, sql);
				if (of.isProcessStatus()) {
					//System.out.println("File " + outFile + "Completed sucessfully ...!");
				}
				DbUtils.close(rset);
			}
			return true;

		} catch (SQLException ex) {
			//Logger.getLogger(ProcessInput.class.getName()).log(Level.SEVERE, null, ex);
			if (!getProcessStatus().equals(Status.cancelled)){
				setProcessStatus(Status.failed);
			}
			MainView.log.log(Level.SEVERE, ex.toString(), ex);
		} catch (Exception ex) {
			//Logger.getLogger(ProcessInput.class.getName()).log(Level.SEVERE, null, ex);
			if (!getProcessStatus().equals(Status.cancelled)){
				setProcessStatus(Status.failed);
			}
			MainView.log.log(Level.SEVERE, ex.toString(), ex);
		}
		return false;

	}

	/**
	 * Writes the results to an XLSX file
	 * 
	 * @param title
	 * @return
	 */
	private boolean writeXLSX(String title) {
		try {
			ResultSet rset = getResultSet(conn);
			if (rset != null) {
				WriteOutputXLSX of = new WriteOutputXLSX(rset, outFile, title, sql, 
						config.getColumnHeaderColor(), config.getBodyColor());
				if (of.isProcessStatus()) {
					//System.out.println("File " + outFile + "Completed sucessfully ...!");
				}
				DbUtils.close(rset);
			}
			return true;

		} catch (SQLException ex) {
			//Logger.getLogger(ProcessInput.class.getName()).log(Level.SEVERE, null, ex);
			if (!getProcessStatus().equals(Status.cancelled)){
				setProcessStatus(Status.failed);
			}
			MainView.log.log(Level.SEVERE, ex.toString(), ex);
		} catch (Exception ex) {
			//Logger.getLogger(ProcessInput.class.getName()).log(Level.SEVERE, null, ex);
			if (!getProcessStatus().equals(Status.cancelled)){
				setProcessStatus(Status.failed);
			}
			MainView.log.log(Level.SEVERE, ex.toString(), ex);
		}
		return false;

	}

	/**
	 * Reads in the xls input file
	 * 
	 * @return
	 */
	private boolean readXLS() {
		ReadInputXLS process = new ReadInputXLS(inpFile);

		if (process.isInputProcessed()) {
			sql = process.getSqlString();
			//TODO: put it logger            System.out.println("SQL Statement: " + sql);
		}
		return process.isInputProcessed();
	}

	/**
	 * Reads in the xlsx input file
	 * 
	 * @return
	 */
	private boolean readXLSX() {
		ReadInputXLSX process = new ReadInputXLSX(inpFile);

		if (process.isInputProcessed()) {
			sql = process.getSqlString();
			//TODO: put it logger            System.out.println("SQL Statement: " + sql);
		}
		return process.isInputProcessed();
	}

	/**
	 * Creates a ResultSet object and returns it
	 * 
	 * @param conn
	 * @return
	 * @throws SQLException
	 * @throws Exception
	 */
	private ResultSet getResultSet(Connection conn) throws SQLException, Exception {
		if (sql == null) {
			return null;
		}
		try {
			stmt = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY,
					ResultSet.CONCUR_READ_ONLY);
			//stmt.setFetchSize(50);
			//stmt.setMaxRows(500);
			//TODO: Put it in logger        
			//        System.out.println("Executing query: " + sql);
			ResultSet rset = stmt.executeQuery(sql);
			return rset;
		} catch(SqlNonTransientConnectionException e){
			MainView.log.log(Level.SEVERE, e.toString(), e);
			Thread.sleep(5000);
			return null;
		} catch(DisconnectNonTransientConnectionException e2){
			MainView.log.log(Level.SEVERE, e2.toString(), e2);
			Thread.sleep(5000);
			return null;
		} catch(ClientRerouteException e3){
			MainView.log.log(Level.SEVERE, e3.toString(), e3);
			Thread.sleep(5000);
			return null;
		}
	}

	/**
	 * Returns the current process status.
	 * 
	 * @return
	 */
	public String getProcessStatus(){
		return this.processStatus;
	}

	/**
	 * Sets the objects process status to the given string.
	 * 
	 * @param ps
	 */
	public void setProcessStatus(String ps){
		this.processStatus = ps;
	}

	/**
	 * Closes the connection
	 */
	public void closeConnection(){
		DbUtils.close(this.conn);
	}
	
	/**
	 * Opens a connection to the DB
	 * 
	 * @return
	 */
	public boolean openConnection(){
		try {
			conn = FileProcess.getDBConnection();
		} catch (ClassNotFoundException e) {
			return false;
		}
		return true;
	}

	@Override
	public void run() {
		generateOutput();
	}
}
