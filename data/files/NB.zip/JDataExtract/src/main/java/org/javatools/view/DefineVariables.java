package org.javatools.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import org.javatools.websql.ProcessInput;

/**
 * @author bob.reaman
 *
 */
public class DefineVariables extends JFrame {

	private static final long serialVersionUID = 1L;
	static JFrame frame;
	static JPanel main, labels, info, buttons, buttons2;
	static JScrollPane scroll;
	static JLabel varsL, valsL, numL;
	static JButton submit, cancel;
	public static ArrayList<String> vars;
	static ArrayList<JTextField> values;
	static ArrayList<JCheckBox> numeric;
	public static HashMap<String, String> hm;
	static boolean cancelled;
	static volatile boolean finished;
	static String fileName;

	public DefineVariables(String title){
		super(title);

		buildLabelsPanel();

		buildInfoPanel();
		scroll = new JScrollPane(info);
		if ((vars.size()*31 + 128) > 500){
			scroll.setPreferredSize(new Dimension(460, 368));
		}

		buildButtonPanel();

		main = new JPanel();
		main.setBackground(Color.LIGHT_GRAY);
		main.setLayout(new GridBagLayout());
		main.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder(""),
				BorderFactory.createEmptyBorder(10, 10, 5, 10)));
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(2, 0, 8, 0);
		JLabel message = new JLabel("Please provide vaules for all variables in " + fileName);
		main.add(message, gbc);
		gbc.gridy++;
		main.add(labels, gbc);
		gbc.gridy++;
		main.add(scroll, gbc);
		gbc.gridy++;
		main.add(buttons2, gbc);
		add(main);

		if ((vars.size()*31 + 147) < 500){
			setSize(new Dimension(500, vars.size()*31 + 147));
		} else {
			setSize(new Dimension(500, 518));
		}
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		setVisible(true);
	}

	public void buildLabelsPanel(){
		varsL = new JLabel("Variable:");
		valsL = new JLabel("Value:");
		numL = new JLabel("Numeric:");

		JPanel varsP, valsP, numP;
		varsP = new JPanel();
		varsP.setBackground(Color.LIGHT_GRAY);
		varsP.setLayout(new GridBagLayout());
		GridBagConstraints gbcP1 = new GridBagConstraints();
		gbcP1.gridx = 0;
		gbcP1.gridy = 0;
		gbcP1.insets = new Insets(0, 20, 0, 70);
		varsP.add(varsL, gbcP1);

		valsP = new JPanel();
		valsP.setBackground(Color.LIGHT_GRAY);
		valsP.setLayout(new GridBagLayout());
		GridBagConstraints gbcP2 = new GridBagConstraints();
		gbcP2.gridx = 0;
		gbcP2.gridy = 0;
		gbcP2.insets = new Insets(0, 80, 0, 100);
		valsP.add(valsL, gbcP2);

		numP = new JPanel();
		numP.setBackground(Color.LIGHT_GRAY);
		numP.setLayout(new GridBagLayout());
		GridBagConstraints gbcP3 = new GridBagConstraints();
		gbcP3.gridx = 0;
		gbcP3.gridy = 0;
		gbcP3.insets = new Insets(0, 45, 0, 0);
		numP.add(numL, gbcP3);

		labels = new JPanel();
		labels.setBackground(Color.LIGHT_GRAY);
		labels.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(0, 0, 0, 0);

		labels.add(varsP, gbc);
		gbc.gridx++;
		labels.add(valsP, gbc);
		gbc.gridx++;
		labels.add(numP, gbc);
	}

	public void buildInfoPanel(){
		info = new JPanel();
		info.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(5, 10, 5, 10);
		info.setBackground(Color.WHITE);
		values = new ArrayList<JTextField>();
		numeric = new ArrayList<JCheckBox>();

		Dimension d = new Dimension(180, 20);

		for (int i = 0; i < vars.size(); i++){
			JTextField temp1 = new JTextField();
			temp1.setText(vars.get(i));
			if (temp1.getSize().width < d.width){
				temp1.setPreferredSize(d);
			} else {
				temp1.setPreferredSize(new Dimension(temp1.getSize().width, 25));
			}
			temp1.setEditable(false);
			JTextField temp2 = new JTextField();
			temp2.setPreferredSize(d);
			JCheckBox temp3 = new JCheckBox();
			values.add(temp2);
			numeric.add(temp3);
			info.add(temp1, gbc);
			gbc.gridx++;
			info.add(temp2, gbc);
			gbc.gridx++;
			info.add(temp3, gbc);
			gbc.gridy++;
			gbc.gridx = 0;
		}
	}

	public void buildButtonPanel(){
		buttons = new JPanel();
		buttons.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(0, 10, 0, 0);
		buttons.setBackground(Color.LIGHT_GRAY);

		submit = new JButton("Submit");
		submit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (valueCheck()){
					createHashMap();
					finished = true;
				} else {
					MessageWindow.displayError("You must provide a value for each variable");
				}
			}
		});

		cancel = new JButton("Cancel");
		cancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				cancelled = true;
				finished = true;
			}
		});

		buttons.add(submit, gbc);
		gbc.gridx++;
		buttons.add(cancel, gbc);

		buttons2 = new JPanel();
		buttons2.setLayout(new GridBagLayout());
		GridBagConstraints gbc2 = new GridBagConstraints();
		gbc2.gridx = 0;
		gbc2.gridy = 0;
		gbc2.insets = new Insets(0, 277, 0, 0);
		buttons2.setBackground(Color.LIGHT_GRAY);
		buttons2.add(buttons, gbc2);
	}

	/**
	 * Check that the user entered a value for each variable in the given sql file
	 * 
	 * @return true or false
	 */
	public boolean valueCheck(){
		for (int i = 0; i < values.size(); i++){
			if (values.get(i).getText() == null || values.get(i).getText().trim().length() == 0){
				return false;
			}
		}
		return true;
	}

	/**
	 * Creates a hashmap with each variable and its user given value for each key/value
	 */
	public void createHashMap(){
		hm = new HashMap<>();
		for (int i = 0; i < values.size(); i ++){
			if (numeric.get(i).isSelected()){
				hm.put(vars.get(i), values.get(i).getText().trim());
			} else {
				hm.put(vars.get(i), "\'" + values.get(i).getText().trim() + "\'");
			}
		}

	}

	/**
	 * Takes an array list of variable names, and the name of the sql file as parameters.
	 * Dynamically creates a new window that allows the user to enter a value for each variable
	 * in the given file, then creates a hashmap of variables and values. Then either returns 
	 * the hashmap or null if the user clicks cancel.
	 * 
	 * @param al
	 * @param file
	 * @return
	 */
	public static HashMap<String, String> getVarValues(ArrayList<String> al, String file) {
		finished = false;
		cancelled = false;
		vars = al;
		fileName = file;
		frame = new DefineVariables("New Jersey Judiciary");
		while (!finished){
			try {
				Thread.sleep(500);
			} catch(InterruptedException e) {

			}
		}
		frame.setVisible(false);
		frame.dispose();
		if (hm == null || cancelled){
			return null;
		}
		return hm;
	}

	//main method for testing purposes
	/*public static void main(String[] args){
		ArrayList<String >vars2 = new ArrayList<String>();
		vars2.add("TABLE_PREFIX1");
		vars2.add("TABLE_PREFIX2");
		vars2.add("TABLE_PREFIX3");
		vars2.add("TABLE_PREFIX4");
		vars2.add("CONTROL_ID");

		vars = vars2;
		fileName = "file.sql";
		frame = new DefineVariables("JDataExtract");
	}*/
}
