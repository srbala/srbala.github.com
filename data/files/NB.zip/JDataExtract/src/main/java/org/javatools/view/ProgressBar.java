package org.javatools.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import javax.swing.border.EmptyBorder;

/**
 * @author bob.reaman
 *
 */
public class ProgressBar implements Runnable {

	public boolean finished = false;
	JFrame frame;

	public ProgressBar(){
		frame = new JFrame("New Jersey Judiciary");
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.setResizable(false);
		Dimension d = new Dimension(260, 107);
		frame.setPreferredSize(d);
		frame.setSize(d);
		frame.setLayout(new BorderLayout());
		frame.add(new InfoPanel());
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}


	public class InfoPanel extends JPanel {

		private static final long serialVersionUID = 1L;
		private JLabel gif, message;

		public InfoPanel() {

			setBorder(new EmptyBorder(-3, -10, 0, 10));
			setBackground(Color.WHITE);
			gif = new JLabel();
			gif.setBorder(new EmptyBorder(10, 10, 0, 15));
			ImageIcon icon = new ImageIcon(getClass().getResource("/img/inProgress.gif"));
			gif.setIcon(icon);
			message = new JLabel("Files are being processed...");
			add(gif);
			add(message);
		}
	}

	@Override
	public void run() {
		while (!finished){

		}
		frame.setVisible(false);
		frame.dispose();
	}
}
