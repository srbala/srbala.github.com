/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.javatools.websql;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import org.javatools.view.MainView;
/**
 *
 * @author bsraman
 */
public class ReadInputXLS {
    private String inputFileWithPath;
    private String inputSheetName;
    private short inputSheetNumber;
    private short rowNumber;
    private short colNumber;
    private String sqlString;
    private boolean inputProcessed;
    
    private ReadInputXLS(){
        // avoid calling empty constructor directly
    }
    
    public ReadInputXLS(String inputFileWithPath){
        this.inputFileWithPath = inputFileWithPath;
        this.inputSheetName = null;
        this.inputSheetNumber = 1;
        this.rowNumber = 1;
        this.colNumber = 0;
        this.sqlString = null;
        this.inputProcessed = pocessInputFile();
    }

    /**
     * @return the inputFileWithPath
     */
    public String getInputFileWithPath() {
        return inputFileWithPath;
    }

    /**
     * @param inputFileWithPath the inputFileWithPath to set
     */
    public void setInputFileWithPath(String inputFileWithPath) {
        this.inputFileWithPath = inputFileWithPath;
        this.setInputProcessed(false);
    }

    /**
     * @return the inputSheetName
     */
    public String getInputSheetName() {
        return inputSheetName;
    }

    /**
     * @param inputSheetName the inputSheetName to set
     */
    public void setInputSheetName(String inputSheetName) {
        this.inputSheetName = inputSheetName;
        this.setInputProcessed(false);
    }

    /**
     * @return the inputSheetNumber
     */
    public short getInputSheetNumber() {
        return inputSheetNumber;
    }

    /**
     * @param inputSheetNumber the inputSheetNumber to set
     */
    public void setInputSheetNumber(short inputSheetNumber) {
        this.inputSheetNumber = inputSheetNumber;
        this.setInputProcessed(false);
    }

    /**
     * @return the rowNumber
     */
    public short getRowNumber() {
        return rowNumber;
    }

    /**
     * @param rowNumber the rowNumber to set
     */
    public void setRowNumber(short rowNumber) {
        this.rowNumber = rowNumber;
        this.setInputProcessed(false);
    }

    /**
     * @return the colNumber
     */
    public short getColNumber() {
        return colNumber;
    }

    /**
     * @param colNumber the colNumber to set
     */
    public void setColNumber(short colNumber) {
        this.colNumber = colNumber;
        this.setInputProcessed(false);
    }

    /**
     * @return the sqlString
     */
    public String getSqlString() {
        if (!isInputProcessed()){
            this.setInputProcessed(this.pocessInputFile());
        }
        return sqlString;
    }

    /**
     * @param sqlString the sqlString to set
     */
    public void setSqlString(String sqlString) {
        this.sqlString = sqlString;
    }

    /**
     * @return the inputProcessed
     */
    public boolean isInputProcessed() {
        return inputProcessed;
    }

    /**
     * @param inputProcessed the inputProcessed to set
     */
    private void setInputProcessed(boolean inputProcessed) {
        this.inputProcessed = inputProcessed;
    }

    /**
     * @param inputProcessed the inputProcessed to set
     */
    private boolean pocessInputFile() {
        boolean processStatus = false;
        try {
            if (this.getInputFileWithPath () == null) {
                return  processStatus;
            }
            POIFSFileSystem fs = new POIFSFileSystem(new FileInputStream(this.getInputFileWithPath()));
            HSSFWorkbook wb = new HSSFWorkbook(fs);
            HSSFSheet sheet;
            if (this.getInputSheetName() == null) {
                sheet = wb.getSheetAt(this.getInputSheetNumber());
            } else {
                sheet = wb.getSheet(this.getInputSheetName());
            }
            HSSFRow row = sheet.getRow(this.getRowNumber());
            HSSFCell cell = row.getCell(this.colNumber);
            HSSFRichTextString sql = cell.getRichStringCellValue();
            this.setSqlString(sql.getString());
//            System.out.println("SQL Statement: " + sql.getString());
            processStatus = true;
//            Logger.getLogger(ReadInputXLS.class.getName()).log(Level.WARNING, "SQL Statement", getSqlString());
        } catch (FileNotFoundException ex) {
            //Logger.getLogger(ReadInputXLS.class.getName()).log(Level.SEVERE, null, ex);
        	MainView.log.log(Level.SEVERE, ex.toString(), ex);
        } catch (IOException ex) {
            //Logger.getLogger(ReadInputXLS.class.getName()).log(Level.SEVERE, null, ex);
        	MainView.log.log(Level.SEVERE, ex.toString(), ex);
        } 

        return processStatus;
    }    
}
