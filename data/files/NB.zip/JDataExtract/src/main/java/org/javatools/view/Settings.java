package org.javatools.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.text.AbstractDocument;

import org.javatools.util.*;
import org.javatools.websql.ReadConfigProperties;

/**
 * @author bob.reaman
 *
 */
public class Settings extends JFrame implements Serializable {
	
	private static final long serialVersionUID = 1L;
	static JFrame settings;
	JPanel panel, left, right, buttons;
	JButton save, close;
	JLabel logFileL, outputL, colorHeaderL, colorBodyL, driverL, dbL, outTypeL, 
		versionL, headColorL, bodyColorL, headerMainL, headerSubL;
	JTextField logFileTF, outputTF, driverTF, headerMainTF, headerSubTF;
	String[] colors = {"None", "Aqua", "Gray", "Green", "Orange", "Yellow"};
	JRadioButton[] headColors, bodyColors;
	ButtonGroup headButtons, bodyButtons;
	static JComboBox<String> dbMenu, outTypeMenu;
	final static Dimension screenSize = new Dimension(930, 450);
	private static ReadConfigProperties config;
	
	public Settings(String title){
		super(title);
		
		buildLeftPanel();
		buildRightPanel();
		buildButtonsPanel();
		
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(10, 5, 10, 5);
		gbc.anchor = GridBagConstraints.WEST;
		
		panel.add(left, gbc);
		gbc.gridx++;
		panel.add(right, gbc);
		gbc.gridx = 0;
		gbc.gridy++;
		gbc.gridwidth = 2;
		gbc.insets = new Insets(5, 5, 10, 5);
		panel.add(buttons, gbc);
		
		add(panel);
	}
	
	public void buildLeftPanel(){
		dbL = new JLabel("Database:");
		dbMenu = new JComboBox<>(MainView.dbs);
		dbMenu.setSelectedItem(config.getDB());
		outTypeL = new JLabel("Output Type:");
		outTypeMenu = new JComboBox<String>(MainView.fileTypes);
		outTypeMenu.setSelectedItem(config.getOutputType());
		driverL = new JLabel("Driver:");
		driverTF = new JTextField();
		driverTF.setText(config.getDriverName());
		Dimension d = new Dimension(310, 25);
		driverTF.setPreferredSize(d);
		logFileL = new JLabel("Log File Location:");
		logFileTF = new JTextField();
		logFileTF.setText(config.getLogLocation());
		Dimension d2 = new Dimension(400, 25);
		logFileTF.setPreferredSize(d2);
		outputL = new JLabel("Output Directory:");
		outputTF = new JTextField();
		outputTF.setText(config.getOutputDir());
		outputTF.setPreferredSize(d2);
		
		left = new JPanel();
		left.setBackground(Color.WHITE);
		left.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder("Default Settings"),
				BorderFactory.createEmptyBorder(40, 5, 50, 5)));
		left.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(0, 10, 15, 10);
		gbc.anchor = GridBagConstraints.WEST;
		
		left.add(dbL, gbc);
		gbc.gridx++;
		left.add(dbMenu, gbc);
		gbc.gridy++;
		gbc.gridx = 0;
		left.add(outTypeL, gbc);
		gbc.gridx++;
		left.add(outTypeMenu, gbc);
		gbc.gridx = 0;
		gbc.gridy++;
		left.add(driverL, gbc);
		gbc.gridx++;
		left.add(driverTF, gbc);
		gbc.insets = new Insets(0, 10, 10, 10);
		gbc.gridx = 0;
		gbc.gridy++;
		gbc.gridwidth = 2;
		gbc.insets = new Insets(0, 10, 5, 10);
		left.add(logFileL, gbc);
		gbc.gridy++;
		gbc.insets = new Insets(0, 10, 14, 10);
		left.add(logFileTF, gbc);
		gbc.gridy++;
		gbc.insets = new Insets(0, 10, 5, 10);
		left.add(outputL, gbc);
		gbc.gridy++;
		gbc.insets = new Insets(0, 10, 10, 10);
		left.add(outputTF, gbc);
	}
	
	public void buildRightPanel(){
		Dimension d = new Dimension(400, 25);
		headerMainL = new JLabel("Main Header:");
		headerMainTF = new JTextField();
		headerMainTF.setText(config.getMainHeader());
		headerMainTF.setPreferredSize(d);
		headerSubL = new JLabel("Sub-Header:");
		headerSubTF = new JTextField();
		headerSubTF.setText(config.getSubHeader());
		headerSubTF.setPreferredSize(d);
		headColorL = new JLabel("Column Header Color:");
		headButtons = new ButtonGroup();
		headColors = new JRadioButton[colors.length];
		for (int i = 0; i < colors.length; i++){
			JRadioButton rb = new JRadioButton(colors[i]);
			if (colors[i].equals(config.getColumnHeaderColor())){
				rb.setSelected(true);
			}
			rb.setBackground(Color.WHITE);
			headButtons.add(rb);
			headColors[i] = rb;
		}
		
		bodyColorL = new JLabel("Body Color:");
		bodyButtons = new ButtonGroup();
		bodyColors = new JRadioButton[colors.length];
		for (int i = 0; i < colors.length; i++){
			JRadioButton rb = new JRadioButton(colors[i]);
			if (colors[i].equals(config.getBodyColor())){
				rb.setSelected(true);
			}
			rb.setBackground(Color.WHITE);
			bodyButtons.add(rb);
			bodyColors[i] = rb;
		}
		
		right = new JPanel();
		right.setBackground(Color.WHITE);
		right.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder("Excel Settings"),
				BorderFactory.createEmptyBorder(15, 5, 20, 5)));
		right.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(0, 10, 5, 10);
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridwidth = 2;
		
		right.add(headerMainL, gbc);
		gbc.gridy++;
		gbc.insets = new Insets(0, 10, 14, 10);
		right.add(headerMainTF, gbc);
		gbc.gridy++;
		gbc.insets = new Insets(0, 10, 5, 10);
		right.add(headerSubL, gbc);
		gbc.gridy++;
		gbc.insets = new Insets(0, 10, 10, 10);
		right.add(headerSubTF, gbc);
		gbc.gridy++;
		gbc.insets = new Insets(10, 55, 5, 10);
		gbc.gridwidth = 1;
		right.add(headColorL, gbc);
		gbc.insets = new Insets(0, 55, 0, 10);
		gbc.gridy++;
		int i;
		for (i = 0; i < headColors.length; i++){
			right.add(headColors[i], gbc);
			gbc.gridy++;
		}
		gbc.gridy = gbc.gridy - (i + 1);
		gbc.gridx++;
		gbc.insets = new Insets(10, 100, 5, 10);
		right.add(bodyColorL, gbc);
		gbc.insets = new Insets(0, 100, 0, 10);
		gbc.gridy++;
		for (i = 0; i < bodyColors.length; i++){
			right.add(bodyColors[i], gbc);
			gbc.gridy++;
		}
	}
	
	public void buildButtonsPanel(){
		save = new JButton("Save");
		save.addActionListener(new ActionListener() {

			@SuppressWarnings("static-access")
			@Override
			public void actionPerformed(ActionEvent e) {
				
				boolean outDir = false;
				boolean driver = false;
				boolean db = false;
				boolean outType = false;
				
				if (!outputTF.getText().equals(config.getOutputDir())){
					outDir = true;
				}
				if (!driverTF.getText().equals(config.getDriverName())){
					driver = true;
				}
				if (!dbMenu.getSelectedItem().toString().equals(config.getDB())){
					db = true;
				}
				if (!outTypeMenu.getSelectedItem().toString().equals(config.getOutputType())){
					outType = true;
				}
				
				config.saveDriverName(driverTF.getText());
				config.saveDB(dbMenu.getSelectedItem().toString());
				config.saveOutputType(outTypeMenu.getSelectedItem().toString());
				if (!config.getLogLocation().equals(logFileTF.getText())){
					MessageWindow.displayMessage("The new log file location will take effect next time you start JDataExtract.");
				}
				config.saveLogLocation(logFileTF.getText());
				config.saveOutputDir(outputTF.getText());
				config.saveMainHeader(headerMainTF.getText());
				config.saveSubHeader(headerSubTF.getText());
				
				for (int i = 0; i < headColors.length; i++){
					if (headColors[i].isSelected()){
						config.saveColumnHeaderColor(headColors[i].getText());
						break;
					}
				}
				
				for (int i = 0; i < bodyColors.length; i++){
					if (bodyColors[i].isSelected()){
						config.saveBodyColor(bodyColors[i].getText());
						break;
					}
				}
				
				config.saveSettings();
				MainView.refresh(outDir, driver, db, outType);
				MainView.toggleSettings();
				settings.setVisible(false);
				settings.dispose();
			}
		});
		
		close = new JButton("Close");
		close.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				MainView.toggleSettings();
				settings.setVisible(false);
				settings.dispose();
			}
		});
		
		JPanel versionPanel = new JPanel(); 
		versionL = new JLabel("Version " + MainView.version);
		versionPanel.setLayout(new GridBagLayout());
		versionPanel.setBackground(Color.WHITE);
		GridBagConstraints gbc2 = new GridBagConstraints();
		gbc2.gridx = 0;
		gbc2.gridy = 0;
		gbc2.insets = new Insets(0, 0, 0, 687);
		gbc2.anchor = GridBagConstraints.WEST;
		versionPanel.add(versionL, gbc2);

		buttons = new JPanel();
		buttons.setBackground(Color.WHITE);
		buttons.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(0, 0, -15, 0);

		buttons.add(versionPanel, gbc);
		gbc.insets = new Insets(0, 0, 0, 10);
		gbc.gridx++;
		buttons.add(save, gbc);
		gbc.gridx++;
		buttons.add(close, gbc);
	}
	
	/**
	 * Opens up a settings window which allows the user to set and change the default settings
	 * of the application.  When the user clicks "save", all of the settings are saved in a
	 * properties file and the settings that were changed are updated in the main window immediately.
	 * 
	 * @param c
	 * @return
	 */
	public static JFrame settings(ReadConfigProperties c){
		config = c;
		settings = new Settings("JDataExtract Settings");
		settings.setPreferredSize(screenSize);
		settings.setResizable(false);
		settings.setMinimumSize(screenSize);
		settings.setLocationRelativeTo(null);
		settings.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		settings.setVisible(true);
		return settings;
	}
	
	//for testing purposes only
/*	public static void main(String[] args){
		settings = new Settings("JDataExtract Settings");
		settings.setPreferredSize(screenSize);
		settings.setResizable(false);
		settings.setMinimumSize(screenSize);
		settings.setLocationRelativeTo(null);
		settings.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		settings.setVisible(true);
	}*/
}
