package org.javatools.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import org.javatools.util.Encryption;
import org.javatools.websql.FileProcess;
import org.javatools.websql.ReadConfigProperties;

import java.util.Base64;


/**
 * @author bob.reaman
 *
 */
public class MainView extends JFrame {

	private static final long serialVersionUID = 1L;
	static JFrame ui, set;
	static JLabel headerPic0, headerPic1;
	static JPanel panel, header, mainButtonsPanel, dirPanel, credPanel, infoPanel;
	static JLabel driverL, dbL, userNameL, passwordL, outputL, outTypeL, inputL, versionL;
	static JTextField driverTF, userNameTF, passwordTF, outputTF, inputTF;
	static JComboBox<String> dbMenu, outTypeMenu;
	static JButton add1, add1file, clear1, add2, clear2, exit, run, settings;
	static JFileChooser fc;
	static JCheckBox rememberMe;
	public static Logger log = Logger.getLogger("JDataExtract Log");
	static FileHandler fh;
	public static boolean success;
	public static boolean settingsActive;
	public final static String version = "1.1";
	public final static ReadConfigProperties config = ReadConfigProperties.getInstance();
	private static Properties loginProperties;
	private static String loginPropLocation = "properties/login.properties";
	byte[] encryptedPass;
	boolean keyCreated = false;
	public static boolean mainViewRun = false;
	String KEY;

	JScrollPane scroll;
	//Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	static Dimension screenSize = new Dimension(1000, 620);
	public static String[] dbs = {"DB2D", "DB2P", "DB14", "DBWP", "DB2T", "DBWD", "DBWT"};
	public static String[] fileTypes = {"xlsx", "xls", "csv"};

	public static String driver, userName, password, db, inputDir, outputDir, outFileType;

	public MainView(String title){
		super(title);

		buildHeader();
		buildDirPanel();
		buildCredPanel();
		buildInfoPanel();
		buildMainButtonsPanel();

		JPanel panel4 = new JPanel();
		panel4.setBackground(Color.WHITE);
		panel4.setLayout(new GridBagLayout());
		GridBagConstraints gbc3 = new GridBagConstraints();
		gbc3.gridx = 0;
		gbc3.gridy = 0;
		gbc3.insets = new Insets(10, 0, 0, 0);
		gbc3.anchor = GridBagConstraints.WEST;
		panel4.add(infoPanel, gbc3);
		gbc3.gridx++;
		gbc3.insets = new Insets(10, 49, 0, 0);
		panel4.add(credPanel, gbc3);

		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.WHITE);
		panel2.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(0, 10, 10, 10);
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridwidth = 2;
		panel2.add(dirPanel, gbc);
		gbc.gridy++;
		panel2.add(panel4, gbc);

		JPanel panel3 = new JPanel();
		panel3.setBackground(Color.WHITE);
		panel3.setLayout(new GridBagLayout());
		GridBagConstraints gbc2 = new GridBagConstraints();
		gbc2.gridx = 0;
		gbc2.gridy = 0;
		gbc2.insets = new Insets(0, 10, 10, 10);
		gbc2.anchor = GridBagConstraints.NORTH;
		panel3.add(header, gbc2);
		gbc2.gridy++;
		gbc2.anchor = GridBagConstraints.CENTER;
		panel3.add(panel2, gbc2);
		gbc2.gridy++;
		gbc2.anchor = GridBagConstraints.SOUTH;
		gbc2.insets = new Insets(0, 0, 0, 172);
		panel3.add(mainButtonsPanel, gbc2);

		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		//panel.add(header);
		panel.add(panel3);
		//panel.add(mainButtonsPanel);
		add(panel);
	}

	public void buildHeader(){
		header = new JPanel();
		header.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		//gbc.insets = new Insets(5, Math.round((float)screenSize.width * (float)0.197), 10, Math.round((float)screenSize.width * (float)0.194));
		gbc.insets = new Insets(0, 20, 0, 30);
		header.setSize(new Dimension(this.getWidth(), this.getHeight()));
		ImageIcon icon0 = new ImageIcon(getClass().getResource("/img/statelogo.png"));
		ImageIcon icon1 = new ImageIcon(getClass().getResource("/img/header3.gif"));
		headerPic0 = new JLabel();
		headerPic0.setIcon(icon0);
		header.add(headerPic0, gbc);
		gbc.gridx++;
		headerPic1 = new JLabel();
		headerPic1.setIcon(icon1);
		header.add(headerPic1, gbc);
		header.setBackground(Color.WHITE);
	}

	public void buildDirPanel(){
		inputL = new JLabel("Input Directory/File:");
		inputTF = new JTextField();
		inputTF.setPreferredSize(new Dimension(800, 25));

		outputL = new JLabel("Output Directory:");
		outputTF = new JTextField();
		outputTF.setText(config.getOutputDir());
		outputTF.setPreferredSize(new Dimension(800, 25));

		add1 = new JButton("Add Directory");
		add1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				//Set up file chooser
				fc = new JFileChooser("C:\\");
				fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				fc.setMultiSelectionEnabled(false);

				if (fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
					inputDir = fc.getSelectedFile().getAbsolutePath() + "\\";
					inputTF.setText(inputDir);
				}
			}
		});

		clear1 = new JButton("Clear");
		clear1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				inputTF.setText("");
			}
		});

		add1file = new JButton("Add File");
		add1file.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				//Set up file chooser
				fc = new JFileChooser("C:\\");
				fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
				fc.setMultiSelectionEnabled(false);

				if (fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
					inputDir = fc.getSelectedFile().getAbsolutePath();
					inputTF.setText(inputDir);
				}
			}
		});

		add2 = new JButton("Add");
		add2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				//Set up file chooser
				fc = new JFileChooser("C:\\");
				fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				fc.setMultiSelectionEnabled(false);

				if (fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
					outputDir = fc.getSelectedFile().getAbsolutePath() + "\\";
					outputTF.setText(outputDir);
				}
			}
		});

		clear2 = new JButton("Clear");
		clear2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				outputTF.setText("");
			}
		});

		dirPanel = new JPanel();
		dirPanel.setBackground(Color.WHITE);
		dirPanel.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder("Directories"),
				BorderFactory.createEmptyBorder(15, 15, 20, 15)));
		dirPanel.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.gridwidth = 2;
		gbc.insets = new Insets(10, 10, 0, 10);
		gbc.anchor = GridBagConstraints.WEST;
		dirPanel.add(inputL, gbc);
		gbc.gridy++;
		dirPanel.add(inputTF, gbc);
		gbc.gridy++;
		gbc.anchor = GridBagConstraints.EAST;

		JPanel p1 = new JPanel();
		p1.setBackground(Color.WHITE);
		p1.setLayout(new GridBagLayout());
		GridBagConstraints gbc2 = new GridBagConstraints();
		gbc2.insets = new Insets(0, 10, 0, 0);
		gbc2.gridx = 0;
		gbc2.gridy = 0;
		p1.add(add1, gbc2);
		gbc2.gridx++;
		p1.add(add1file, gbc2);
		gbc2.gridx++;
		p1.add(clear1, gbc2);

		dirPanel.add(p1, gbc);

		gbc.gridx = 0;
		gbc.gridy++;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridwidth = 2;
		dirPanel.add(outputL, gbc);
		gbc.gridy++;
		dirPanel.add(outputTF, gbc);
		gbc.gridy++;
		gbc.anchor = GridBagConstraints.EAST;

		JPanel p2 = new JPanel();
		p2.setBackground(Color.WHITE);
		p2.setLayout(new GridBagLayout());
		GridBagConstraints gbc3 = new GridBagConstraints();
		gbc3.insets = new Insets(0, 10, 0, 0);
		gbc3.gridx = 0;
		gbc3.gridy = 0;
		p2.add(add2, gbc3);
		gbc3.gridx++;
		p2.add(clear2, gbc3);

		dirPanel.add(p2, gbc);
	}

	public void buildMainButtonsPanel(){
		run = new JButton("Run");
		run.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				inputDir = inputTF.getText();
				outputDir = outputTF.getText();
				driver = driverTF.getText();
				String temp = (String)dbMenu.getSelectedItem();
				userName = userNameTF.getText();
				password = passwordTF.getText();

				if (rememberMe.isSelected()){	//store users login info
					if (!keyCreated){
						KEY = Encryption.buildKey(userName);
					}
					
					try {
						encryptedPass = Encryption.encrypt(password.getBytes(StandardCharsets.US_ASCII), KEY);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					loginProperties.setProperty("login.username", new String(Base64.getEncoder().encode(userName.getBytes())));
					loginProperties.setProperty("login.password", new String(Base64.getEncoder().encode(encryptedPass)));
					try {
						loginProperties.store(new FileOutputStream(loginPropLocation), "");
					} catch (IOException ex) {
						System.out.println("Failed to save");
					}
				} else {	//clear any login info that is currently stored
					loginProperties.setProperty("login.username", "");
					loginProperties.setProperty("login.password", "");
					try {
						loginProperties.store(new FileOutputStream(loginPropLocation), "");
					} catch (IOException ex) {
						System.out.println("Failed to save");
					}
				}

				config.setUsername(userName);
				config.setPassword(password);
				outFileType = (String)outTypeMenu.getSelectedItem().toString().toLowerCase();
				if (temp.compareTo("DB2P") == 0){
					db = "jdbc:db2://172.16.1.27:5025/DB2P";
				}
				else if (temp.compareTo("DB14") == 0){
					db = "jdbc:db2://172.16.1.27:5042/DB14";
				}
				else if (temp.compareTo("DB2D") == 0){
					db = "jdbc:db2://172.16.1.27:446/DB2D";
				}
				else if (temp.compareTo("DBWP") == 0){
					db = "jdbc:db2://172.16.1.27:5036/DBWP";
				}
				else if (temp.compareTo("DB2T") == 0){
					db = "jdbc:db2://172.16.1.27:5021/DB2T";
				}
				else if (temp.compareTo("DB2P") == 0){
					db = "jdbc:db2://172.16.1.27:5025/DB2P";
				}
				else if (temp.compareTo("DBWD") == 0){
					db = "jdbc:db2://172.16.1.27:5034/DBWD";
				}
				else if (temp.compareTo("DBWT") == 0){
					db = "jdbc:db2://172.16.1.27:5031/DBWT";
				}
				config.setUrl(db);

				if (inputDir.equalsIgnoreCase("") || outputDir.equalsIgnoreCase("") || 
						password.equalsIgnoreCase("") || userName.equalsIgnoreCase("") || 
						driver.equalsIgnoreCase("")){
					MessageWindow.displayError("Please complete all fields");
				} else {
					disableExit();
					disableRun();
					Thread t = new Thread(new Runnable(){
						@Override
						public void run() {
							FileProcess.processInput(inputDir, outputDir, config);
							if (success){
								MessageWindow.displayMessage("All files have been processed.");
							} else {
								success = true;
							}
							enableExit();
							enableRun();
						}});
					t.start();
				}
			}
		});

		settings = new JButton("Settings");
		settings.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (!settingsActive){
					toggleSettings();
					set = Settings.settings(config);
				} else {
					set.toFront();
				}
			}
		});

		exit = new JButton("Exit");
		exit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(DISPOSE_ON_CLOSE);
			}
		});

		JPanel versionPanel = new JPanel(); 
		versionL = new JLabel("Version " + version);
		versionPanel.setLayout(new GridBagLayout());
		versionPanel.setBackground(Color.WHITE);
		GridBagConstraints gbc2 = new GridBagConstraints();
		gbc2.gridx = 0;
		gbc2.gridy = 0;
		gbc2.insets = new Insets(0, 125, 0, 637);
		gbc2.anchor = GridBagConstraints.WEST;
		versionPanel.add(versionL, gbc2);

		mainButtonsPanel = new JPanel();
		mainButtonsPanel.setBackground(Color.WHITE);
		mainButtonsPanel.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(0, 0, -15, 0);

		mainButtonsPanel.add(versionPanel, gbc);
		gbc.insets = new Insets(0, 0, 0, 10);
		gbc.gridx++;
		mainButtonsPanel.add(run, gbc);
		gbc.gridx++;
		mainButtonsPanel.add(settings, gbc);
		gbc.gridx++;
		mainButtonsPanel.add(exit, gbc);
	}

	public void buildCredPanel(){
		userNameL = new JLabel("Username:");
		userNameTF = new JTextField();
		userNameTF.setPreferredSize(new Dimension(350, 25));

		try {
			KEY = Encryption.buildKey(new String(Base64.getDecoder().decode(loginProperties.getProperty("login.username"))).trim());
			if (KEY != null){
				keyCreated = true;
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		passwordL = new JLabel("Password:");
		passwordTF = new JPasswordField();
		passwordTF.setPreferredSize(new Dimension(350, 25));

		if (keyCreated){
			try {
				userNameTF.setText(new String(Base64.getDecoder().decode(loginProperties.getProperty("login.username"))).trim());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				passwordTF.setText(new String(Encryption.decrypt(Base64.getDecoder().decode(loginProperties.getProperty("login.password")), KEY)).trim());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		rememberMe = new JCheckBox("Remember Me");
		rememberMe.setSelected(true);
		rememberMe.setBackground(Color.WHITE);

		credPanel = new JPanel();
		credPanel.setBackground(Color.WHITE);
		credPanel.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder("Credentials"),
				BorderFactory.createEmptyBorder(0, 15, 20, 15)));
		credPanel.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(0, 10, 0, 10);
		gbc.anchor = GridBagConstraints.EAST;

		credPanel.add(rememberMe, gbc);
		gbc.gridy++;
		gbc.insets = new Insets(0, 10, 0, 10);
		gbc.anchor = GridBagConstraints.WEST;
		credPanel.add(userNameL, gbc);
		gbc.gridy++;
		gbc.insets = new Insets(10, 10, 0, 10);
		credPanel.add(userNameTF, gbc);
		gbc.gridy++;
		credPanel.add(passwordL, gbc);
		gbc.gridy++;
		credPanel.add(passwordTF, gbc);
	}

	public void buildInfoPanel(){
		driverL = new JLabel("Driver:");
		driverTF = new JTextField();
		driverTF.setText(config.getDriverName());
		Dimension d = new Dimension(250, 25);
		driverTF.setPreferredSize(d);
		dbL = new JLabel("Database:");
		dbMenu = new JComboBox<>(dbs);
		dbMenu.setSelectedItem(config.getDB());
		outTypeL = new JLabel("Output Type:");
		outTypeMenu = new JComboBox<String>(fileTypes);
		outTypeMenu.setSelectedItem(config.getOutputType());

		infoPanel = new JPanel();
		infoPanel.setBackground(Color.WHITE);
		infoPanel.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder("Information"),
				BorderFactory.createEmptyBorder(15, 15, 20, 15)));
		infoPanel.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(10, 10, 5, 10);
		gbc.anchor = GridBagConstraints.EAST;

		infoPanel.add(driverL, gbc);
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx++;
		infoPanel.add(driverTF, gbc);
		gbc.gridy++;
		gbc.gridx = 0;
		gbc.anchor = GridBagConstraints.EAST;
		infoPanel.add(dbL, gbc);
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx++;
		infoPanel.add(dbMenu, gbc);
		gbc.gridy++;
		gbc.gridx = 0;
		gbc.anchor = GridBagConstraints.EAST;
		infoPanel.add(outTypeL, gbc);
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx++;
		infoPanel.add(outTypeMenu, gbc);
	}

	/**
	 * Disables the exit button
	 */
	public static void disableExit(){
		exit.setEnabled(false);
	}

	/**
	 * Enables the exit button
	 */
	public static void enableExit(){
		exit.setEnabled(true);
	}

	/**
	 * Disables the run button
	 */
	public static void disableRun(){
		run.setEnabled(false);
	}

	/**
	 * Enables the run button
	 */
	public static void enableRun(){
		run.setEnabled(true);
	}

	/**
	 * Flips boolean to show if the settings window is active or not
	 */
	public static void toggleSettings(){
		if (settingsActive){
			settingsActive = false;
		} else {
			settingsActive = true;
		}
	}


	/**
	 * refresh only what was just saved by the user for default settings
	 * 
	 * @param outDir
	 * @param driver
	 * @param db
	 * @param outType
	 */
	public static void refresh(boolean outDir, boolean driver, boolean db, boolean outType){
		if (driver){
			driverTF.setText(config.getDriverName());
		}
		if (db){
			dbMenu.setSelectedItem(config.getDB());
		}
		if (outType){
			outTypeMenu.setSelectedItem(config.getOutputType());
		}
		if (outDir){
			outputTF.setText(config.getOutputDir());
		}
	}

	public static void main(String[] args){
		mainViewRun = true;
		loginProperties = new Properties();
		try {
			loginProperties.load(new FileInputStream(loginPropLocation));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");

		//Configure the logger with handler and formatter  
		try {
			fh = new FileHandler(config.getLogLocation() + "\\JDataExtract" 
					+ sdf.format(date) + ".log", true);
			log.addHandler(fh);
			SimpleFormatter formatter = new SimpleFormatter();  
			fh.setFormatter(formatter);  
		} catch (SecurityException | IOException e) {
			System.out.println("Error: Unable to configure logger.");
		}  

		success = true;
		log.info("New JDataExtract session started."); 
		ui = new MainView("JDataExtract");
		//ui.setExtendedState(Frame.MAXIMIZED_BOTH);
		ui.setPreferredSize(screenSize);
		ui.setResizable(false);
		ui.setMinimumSize(screenSize);
		ui.setLocationRelativeTo(null);
		ui.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		ui.setVisible(true);
	}
}
