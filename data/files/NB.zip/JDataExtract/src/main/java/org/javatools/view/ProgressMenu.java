package org.javatools.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import org.javatools.util.Status;
import org.javatools.websql.DbUtils;
import org.javatools.websql.FileProcess;
import org.javatools.websql.ProcessInput;

/**
 * @author bob.reaman
 *
 */
public class ProgressMenu implements Runnable {

	public static JFrame pm;
	static Dimension screenSize = new Dimension(520, 400);
	public boolean finished;
	static JButton cancelAll;
	static JScrollPane scroll;
	static JPanel main, labels, info, buttons;
	static ArrayList<String> fileNames;
	static ArrayList<ProcessInput> PIs;
	static JButton[] cancelButtons;
	static JLabel[] statuses;
	static JLabel file, status;

	/**
	 * Takes array lists of file names and ProcessInput objects as parameters.
	 * Dynamically creates a window that shows each file that is being processed, 
	 * and the status of that file. The user has the ability to cancel a file, re-run
	 * a file, or cancel all files.
	 * 
	 * @param s (File names)
	 * @param p (ProcessInput objects)
	 */
	public ProgressMenu(ArrayList<String> s, ArrayList<ProcessInput> p) {
		fileNames = s;
		PIs = p;
		cancelButtons = new JButton[fileNames.size()];
		statuses = new JLabel[fileNames.size()];
		pm = new JFrame("JDataExtract Settings");

		buildProgressMenu();
		pm.add(main);

		if (fileNames.size() < 9){
			pm.setSize(new Dimension(screenSize.width, fileNames.size()*36 + 100));
		} else {
			pm.setSize(screenSize);
		}
		pm.setResizable(false);
		pm.setLocationRelativeTo(null);
		pm.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		pm.setVisible(true);
	}

	public void buildProgressMenu(){
		main = new JPanel();
		main.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(5, 5, 0, 5);
		main.setBackground(Color.LIGHT_GRAY);

		buildLabelsPanel();
		buildInfoPanel();
		scroll = new JScrollPane(info);
		if ((fileNames.size()*31 + 125) > 400){
			scroll.setPreferredSize(new Dimension(500, 305));
		}
		buildButtonsPanel();

		main.add(labels, gbc);
		gbc.gridy++;
		gbc.insets = new Insets(5, 5, 5, 5);
		main.add(scroll, gbc);
		gbc.gridy++;
		gbc.insets = new Insets(0, 5, 5, 5);
		main.add(buttons, gbc);
	}

	public void buildLabelsPanel(){
		file = new JLabel("File:");
		status = new JLabel("Status:");

		labels = new JPanel();
		labels.setBackground(Color.LIGHT_GRAY);
		labels.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(0, 0, 0, 150);

		labels.add(file, gbc);
		gbc.gridx++;
		gbc.insets = new Insets(0, 0, 0, 100);
		labels.add(status, gbc);
	}

	public void buildInfoPanel(){
		info = new JPanel();
		info.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(5, 5, 5, 5);
		info.setBackground(Color.WHITE);

		Dimension d = new Dimension(180, 20);
		for (int i = 0; i < fileNames.size(); i++){
			final int x = i;
			JLabel fileName = new JLabel();
			fileName.setText(fileNames.get(i));
			fileName.setHorizontalAlignment(JLabel.CENTER);
			fileName.setBorder(BorderFactory.createCompoundBorder(
					BorderFactory.createTitledBorder(""),
					BorderFactory.createEmptyBorder(2, 2, 2, 2)));
			fileName.setPreferredSize(d);

			final JLabel status = new JLabel();
			status.setText(PIs.get(i).getProcessStatus());
			status.setBackground(Color.decode("#01FAFE"));
			status.setOpaque(true);
			status.setHorizontalAlignment(JLabel.CENTER);
			status.setBorder(BorderFactory.createCompoundBorder(
					BorderFactory.createTitledBorder(""),
					BorderFactory.createEmptyBorder(2, 2, 2, 2)));
			status.setPreferredSize(d);
			statuses[i] = status;

			final JButton cancel = new JButton(Status.terminate);
			cancel.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {

					if (cancel.getText().equals(Status.terminate)){

						if (PIs.get(x).getProcessStatus().equals(Status.inProgress)){
							try {
								PIs.get(x).stmt.cancel();
							} catch (SQLException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (Exception e2) {

							}
							PIs.get(x).closeConnection();
							PIs.get(x).setProcessStatus(Status.cancelled);
							cancel.setText("Restart");
							status.setText(PIs.get(x).getProcessStatus());
							statuses[x].setBackground(Color.decode("#FF7912"));
							FileProcess.t.stop();
							PIs.get(x).openConnection();
						} else {
							PIs.get(x).setProcessStatus(Status.cancelled);
							cancel.setText("Restart");
							status.setText(PIs.get(x).getProcessStatus());
							statuses[x].setBackground(Color.decode("#FF7912"));
						}
					} else {
						FileProcess.rescan = true;
						PIs.get(x).setProcessStatus(Status.inQueue);
						cancel.setText(Status.terminate);
						status.setText(PIs.get(x).getProcessStatus());
						statuses[x].setBackground(Color.decode("#01FAFE"));
					}
				}
			});
			cancelButtons[i] = cancel;

			info.add(fileName, gbc);
			gbc.gridx++;
			info.add(status, gbc);
			gbc.gridx++;
			info.add(cancel, gbc);
			gbc.gridy++;
			gbc.gridx = 0;
		}
	}

	public void buildButtonsPanel(){
		cancelAll = new JButton("Cancel All");
		cancelAll.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				MainView.success = false;
				for (int i = 0; i < PIs.size(); i++){
					if (PIs.get(i).getProcessStatus().equals(Status.inProgress)){
						PIs.get(i).setProcessStatus(Status.cancelled);
						try {
							PIs.get(i).stmt.cancel();
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (Exception e2) {

						}
						FileProcess.t.stop();
					} else if (PIs.get(i).getProcessStatus().equals(Status.inQueue)){
						PIs.get(i).setProcessStatus(Status.cancelled);
					}
				}
				finished = true;
			}
		});

		buttons = new JPanel();
		buttons.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(0, 395, 0, 0);
		buttons.setBackground(Color.LIGHT_GRAY);
		buttons.add(cancelAll, gbc);
	}

	/**
	 * Changes the status of the file at the given index
	 * 
	 * @param index
	 * @param status
	 */
	public void statusChange(int index, String status){
		statuses[index].setText(status);
		if (status.equals(Status.complete)){
			cancelButtons[index].setText("Re-run");
			statuses[index].setBackground(Color.GREEN);
		} else if (status.equals(Status.inProgress)){
			statuses[index].setBackground(Color.YELLOW);
		} else if (status.equals(Status.failed)){
			statuses[index].setBackground(Color.decode("#FC3737"));
		}
	}

	//for testing purposes only
/*	public static void main(String[] args){
		ArrayList<String> files = new ArrayList<String>();
		files.add("file1.sql");
		//files.add("file2.sql");
		//files.add("file3.xls");
		//files.add("file4.xls");
		//files.add("file5.xlsx");
		//files.add("file1.sql");
		//files.add("file2.sql");
		//files.add("file3.xls");
		//files.add("file4.xls");
		//files.add("file5.xlsx");
		ProgressMenu p = new ProgressMenu(files, null);
		Thread t = new Thread(p);
		t.start();
	}*/

	@Override
	public void run() {
		finished = false;
		while (!finished){
			try {
				Thread.sleep(500);
			} catch(InterruptedException e) {

			}
		}
		pm.setVisible(false);
		pm.dispose();
	}
}
