package org.javatools.websql;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.sql.RowSet;

/**
 * DbUtils provides some basic methods for handling odd jdbc
 * tasks such as closing a ResultSet, PreparedStatement, ...
 *
 *
 * <p>
 * Date: August 20, 2008
 * <p>
 * @author Balamurugan S. Raman
 * <p>
 * @since 1.0
 * <p>
 */
public class DbUtils {

    /**
     * Closes the given row set
     * 
     * @param rs
     */
    public static void close(RowSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
        }
        catch (Exception e) {
            //ignore
            e.printStackTrace();
        }
    }

    /**
     * Closes the given result set
     * 
     * @param rs
     */
    public static void close(ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
        }
        catch (Exception e) {
            //ignore
            e.printStackTrace();
        }
    }


    /**
     * Closes the given Statement
     * 
     * @param stmt
     */
    public static void close(Statement stmt) {
        try {
            if (stmt != null) {
                stmt.close();
            }
        }
        catch (Exception e) {
            //ignore
            e.printStackTrace();
        }
    }


    /**
     * Closes the given Prepared Statement
     * 
     * @param ps
     */
    public static void close(PreparedStatement ps) {
        try {
            if (ps != null) {
                ps.close();
            }
        }
        catch (Exception e) {
            //ignore
            e.printStackTrace();
        }
    }


    /**
     * Closes the given Connection
     * 
     * @param conn
     */
    public static void close(Connection conn) {
        try {
            if (conn != null) {
                conn.close();
            }
        }
        catch (Exception e) {
            //ignore
            e.printStackTrace();
        }
    }

    /**
     * Returns the current date.
     * 
     * @return
     */
    public static java.sql.Date getJavaSqlDate() {

        java.util.Date javaUtilDate = new java.util.Date();
        return new java.sql.Date(javaUtilDate.getTime());
    }


    /**
     * Gets the value of the indicated column at the current row, trims it, and then
     * returns it.
     * 
     * @param resultSet
     * @param index
     * @return
     * @throws SQLException
     */
    public static String getTrimmedString(ResultSet resultSet, int index)
        throws SQLException {

        String value = resultSet.getString(index);

        if (value != null) {
            value = value.trim();
        }

        return value;
    }


    /**
     * Gets the value of the indicated column at the current row, trims it, and then
     * returns it.
     * 
     * @param resultSet
     * @param columnName
     * @return
     * @throws SQLException
     */
    public static String getTrimmedString(ResultSet resultSet, String columnName)
        throws SQLException {

        String value = resultSet.getString(columnName);

        if (value != null) {
            value = value.trim();
        }

        return value;
    }

}
