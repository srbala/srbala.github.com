package org.javatools.util;


import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class Encryption {
	//private static String KEY = "ASWRYHGQTUJMNCOP";

/*	public static void main(String[] args) throws Exception {

		String plainText = "Hello, this message is like a password";
		System.out.println("Plain Text Before Encryption: " + plainText);

		byte[] plainTextByte = plainText.getBytes(StandardCharsets.US_ASCII);
		byte[] encryptedBytes = encrypt(plainTextByte);

		String encryptedText = new String(encryptedBytes, StandardCharsets.US_ASCII);
		System.out.println("Encrypted Text After Encryption: " + encryptedText);

		byte[] decryptedBytes = decrypt(encryptedBytes);
		String decryptedText = new String(decryptedBytes, StandardCharsets.US_ASCII);
		System.out.println("Decrypted Text After Decryption: " + decryptedText);
	}*/

	public static byte[] encrypt(byte[] plainTextByte, String KEY)
			throws Exception {
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(KEY.getBytes(), "AES"));
		byte[] encryptedBytes = cipher.doFinal(plainTextByte);
		return encryptedBytes;
	}

	public static byte[] decrypt(byte[] encryptedBytes, String KEY)
			throws Exception {
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(KEY.getBytes(), "AES"));
		byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
		return decryptedBytes;
	}

	public static String buildKey(String s){
		if (s.length() < 5){
			return null;
		}
		String KEY = s.substring(0, 5) + "ASWRYHGQTUJ";
		return KEY;
	}
}

