/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.javatools.websql;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.FillPatternType;

import org.javatools.view.MainView;

/**
 *
 * @author bsraman
 */
public class WriteXLS {

    private String outputFileWithPath;
    private String title;
    private ResultSet rs;
    private String sqlString;
    private List<String> columnNames = new ArrayList<String>();
    private List<String> columnTypes = new ArrayList<String>();
    private boolean processStatus;

    private WriteXLS() {
    }

    public WriteXLS(ResultSet rs, String outputFileWithPath, String title, String sqlString) {
        this.outputFileWithPath = outputFileWithPath;
        this.rs = rs;
        this.title = title;
        this.sqlString = sqlString;
        processOutput();
    }

    public void processOutput() {
        // Write the output to a file
        processStatus = false;
        try {
            if (getTitle() == null) {
                File file = new File(getOutputFileWithPath());
                setTitle(file.getName());
            }
            HSSFWorkbook wb = new HSSFWorkbook();
            generateDataSheet(wb);
            generateSqlSheet(wb);
            FileOutputStream fileOut = new FileOutputStream(getOutputFileWithPath());
            wb.write(fileOut);
            fileOut.close();
            processStatus = true;

        } catch (FileNotFoundException ex) {
            //Logger.getLogger(ProcessInput.class.getName()).log(Level.SEVERE, null, ex);
        	MainView.log.log(Level.SEVERE, ex.toString(), ex);
        } catch (IOException ex) {
            //Logger.getLogger(ProcessInput.class.getName()).log(Level.SEVERE, null, ex);
        	MainView.log.log(Level.SEVERE, ex.toString(), ex);
        }
    }

    public void generateDataSheet(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.createSheet("DATA");
        try {
            boolean titleStatus = getTableHeader(wb, sheet, 2);
            if (titleStatus) {
                titleStatus = getTableData(wb, sheet, 3);
            }
            for (short index = 0; index < columnTypes.size(); index++) {
                sheet.autoSizeColumn(index);
            }
            HSSFRow row = sheet.createRow((short) 0);
            HSSFFont font = wb.createFont();
            font.setFontHeightInPoints((short) 16);
            font.setBold(true);
            HSSFCellStyle style = wb.createCellStyle();
            style.setFont(font);
            HSSFRichTextString textString = new HSSFRichTextString(getTitle());
            HSSFCell title1 = row.createCell((short) 0);
            title1.setCellValue(textString);
            title1.setCellStyle(style);
            HSSFRow row1 = sheet.createRow((short) 1);
            File fs = new File(this.outputFileWithPath);
            String title2str = fs.getName();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.S'000'");
            title2str = title2str.substring(0, (title2str.length() - 4)) + " (" + sdf.format(new Date()) + ")";
            HSSFRichTextString textString1 = new HSSFRichTextString(title2str);
            font.setFontHeightInPoints((short) 12);
            HSSFCell title2 = row1.createCell((short) 0);
            title2.setCellValue(textString1);
            title2.setCellStyle(style);
            sheet.createFreezePane(0, 3, 0, 3);
        } catch (SQLException ex) {
            //Logger.getLogger(WriteXLS.class.getName()).log(Level.SEVERE, null, ex);
        	MainView.log.log(Level.SEVERE, ex.toString(), ex);
        }
    }

    public void generateSqlSheet(HSSFWorkbook wb) {
        if (getSqlString() == null) {
            setSqlString("SQL Statement not found");
        }
        HSSFSheet sheet = wb.createSheet("SQL Statement");
        HSSFRow row = sheet.createRow((short) 0);
        HSSFRichTextString textString = new HSSFRichTextString("SQL Statement");
        HSSFCell title1 = row.createCell((short) 0);
        title1.setCellValue(textString);
        HSSFRow row1 = sheet.createRow((short) 1);
        HSSFRichTextString textString1 = new HSSFRichTextString(getSqlString());
        row1.createCell((short) 0).setCellValue(textString1);
    }

    public boolean getTableHeader(HSSFWorkbook wb, HSSFSheet sheet, int rownum)
            throws SQLException {
        if (getRs() == null) {
            return false;
        }
        HSSFRow row = sheet.createRow((short) rownum);
        columnNames.clear();
        columnTypes.clear();


        // get result set meta data
        ResultSetMetaData rsMetaData = getRs().getMetaData();
        int numberOfColumns = rsMetaData.getColumnCount();
        HSSFCellStyle style = wb.createCellStyle();
        style.setFillBackgroundColor(HSSFColor.GREY_25_PERCENT.index);
        style.setFillPattern(FillPatternType.FINE_DOTS);
        HSSFFont font = wb.createFont();
        font.setBold(true);
        style.setFont(font);

        // get the column names; column indexes start from 1
        for (short index = 0; index < numberOfColumns; index++) {
            String columnName = rsMetaData.getColumnName(index + 1);
            columnNames.add(columnName);
            String columnType = rsMetaData.getColumnTypeName(index + 1);
            columnTypes.add(columnType);
            HSSFRichTextString textString = new HSSFRichTextString(columnName);
            HSSFCell cell = row.createCell(index);
            cell.setCellValue(textString);
            cell.setCellStyle(style);
            sheet.autoSizeColumn(index);
        }

        return true;
    }

    public boolean getTableData(HSSFWorkbook wb, HSSFSheet sheet, int rownum)
            throws SQLException {
        if (rs == null) {
            return false;
        }

        int numberOfColumns = columnNames.size();

        HSSFCellStyle dateStyle = wb.createCellStyle();
        HSSFDataFormat format = wb.createDataFormat();
        dateStyle.setDataFormat(format.getFormat("YYYY/MM/DD"));
        // get the column names; column indexes start from 1
        int recNumber = 0;
        while (rs.next()) {
            recNumber = recNumber + 1;
            HSSFRow row = sheet.createRow((short) rownum++);
            for (short index = 0; index < numberOfColumns; index++) {
                if (!columnTypes.get(index).equals("DATE")) {
                    String columnData = getRs().getString(index + 1);
                    if (columnData == null) {
                        columnData = "";
                    }
                    HSSFRichTextString textString = new HSSFRichTextString(columnData);
                    row.createCell(index).setCellValue(textString);
                } else {
                    Date columnData = getRs().getDate(index + 1);
                    if (columnData == null) {
                        columnData = new Date();
                    }
                   HSSFCell cell = row.createCell(index);
                    cell.setCellValue(columnData);
                    cell.setCellStyle(dateStyle);
                }
            }
            if (recNumber > 95000) {
                MainView.log.info("FM0201: File " + outputFileWithPath + " has more then 95 Records; only 95 Records written to out file");
                break;
            }

        }
        if (recNumber == 0) {
            MainView.log.info("FM0202: File " + outputFileWithPath + " has ZERO records in out file");
        }
        
        return true;
    }

    /**
     * @return the outputFileWithPath
     */
    private String getOutputFileWithPath() {
        return outputFileWithPath;
    }

    /**
     * @param outputFileWithPath the outputFileWithPath to set
     */
    private void setOutputFileWithPath(String outputFileWithPath) {
        this.outputFileWithPath = outputFileWithPath;
    }

    /**
     * @return the title
     */
    private String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    private void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the rs
     */
    private ResultSet getRs() {
        return rs;
    }

    /**
     * @param rs the rs to set
     */
    private void setRs(ResultSet rs) {
        this.rs = rs;
    }

    /**
     * @return the sqlString
     */
    private String getSqlString() {
        return sqlString;
    }

    /**
     * @param sqlString the sqlString to set
     */
    private void setSqlString(String sqlString) {
        this.sqlString = sqlString;
    }

    /**
     * @return the processStatus
     */
    public boolean isProcessStatus() {
        return processStatus;
    }
}
