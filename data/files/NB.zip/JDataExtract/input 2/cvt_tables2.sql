select
   a.tbname, a.colno, a.name, a.coltype, a.length, a.keyseq, a.foreignkey, a.default, a.nulls
from
   sysibm.syscolumns a
where
   substr(tbname, 1,4) = &TABLE_PREFIX1 
and CONTROL_ID = &CONTROL_ID
union all   
select
   a.tbname, a.colno, a.name, a.coltype, a.length, a.keyseq, a.foreignkey, a.default, a.nulls
from
   sysibm.syscolumns a
where
   substr(tbname, 1,4) = &TABLE_PREFIX2
and CONTROL_ID = &CONTROL_ID
union all   
select
   a.tbname, a.colno, a.name, a.coltype, a.length, a.keyseq, a.foreignkey, a.default, a.nulls
from
   sysibm.syscolumns a
where
   substr(tbname, 1,4) = &TABLE_PREFIX3
and CONTROL_ID = &CONTROL_ID 
order by 1, 2
