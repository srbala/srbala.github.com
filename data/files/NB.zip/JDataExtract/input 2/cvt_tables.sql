select 
                a.tbname, a.colno, a.name, a.coltype, a.length, a.keyseq, a.foreignkey, a.default, a.nulls
from
                sysibm.syscolumns a
where
                substr(tbname, 1,4) = &TABLE_PREFIX
order by 1, 2
